package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used to provide OSHA user data.
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class OSHAUserData {

	private Integer oshaUserId;

	@Size(min = 0, max = 15)
	private String employeeNumber;

	@Size(min = 0, max = 60)
	private String firstName;

	@Size(min = 0, max = 60)
	private String lastName;

	@Size(min = 0, max = 60)
	private String middleName;

	@Size(min = 0, max = 320)
	private String loginId;

	@Email
	@Size(min = 0, max = 320)
	private String emailAddressText;

	private String office;

	private String rid;
	
	private String fullName;

	private LocalDateTime lastLoginDateTime;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;

	private List<OSHAUserRoleData> listOfRoles;
}
