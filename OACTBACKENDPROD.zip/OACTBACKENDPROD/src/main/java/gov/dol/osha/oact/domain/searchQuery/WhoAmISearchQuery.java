package gov.dol.osha.oact.domain.searchQuery;

import lombok.Data;

/**
 * This class is used for who am i Search
 *
 * @author Skietech Development Team
 */
@Data
public class WhoAmISearchQuery {

	private boolean isAccountManager;
}
