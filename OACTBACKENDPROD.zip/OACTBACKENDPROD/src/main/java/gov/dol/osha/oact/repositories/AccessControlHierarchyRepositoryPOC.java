package gov.dol.osha.oact.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import gov.dol.osha.oact.entities.AccessControlHierarchy;
import gov.dol.osha.oact.entities.AccessControlHierarchyPOC;

/**
 * Repository interface for {@link AccessControlHierarchy} instances. Provides
 * basic CRUD operations due to the extension of {@link JpaRepository}.
 *
 */
public interface AccessControlHierarchyRepositoryPOC extends JpaRepository<AccessControlHierarchyPOC, Integer> {

	List<AccessControlHierarchyPOC> findByCertCoordinatorOshaUserId(final Integer certCoordinatorId);

	List<AccessControlHierarchyPOC> findBySystemOwnerOshaUserId(final Integer systemOwnerId);

	List<AccessControlHierarchyPOC> findBySystemPocOshaUserId(final Integer systemPocId);

	List<AccessControlHierarchyPOC> findByAccountManagerOshaUserId(final Integer accountManagerId);

	List<AccessControlHierarchyPOC> findBySubAccountManagerOshaUserId(final Integer subAccountManagerId);

	List<AccessControlHierarchyPOC> findByAccessControlHierarchyPocId(final Integer accessControlHierarchyPocId);

}
