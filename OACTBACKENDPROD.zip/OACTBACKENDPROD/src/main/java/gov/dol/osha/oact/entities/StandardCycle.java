package gov.dol.osha.oact.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the STND_CYCLE information
 *
 * @author Skietech Development Team
 */
@Table(name = "STND_CYCLE")
@Entity
@Data
@RequiredArgsConstructor
public class StandardCycle {

	@Id
	@GeneratedValue
	@Column(name = "STND_CYCLE_ID")
	private Integer stndCycleId;

	@Size(min = 0, max = 20)
	@Column(name = "CYCLE_NM", length = 20)
	private String cycleName;

	@NotBlank(message = "Stnd cycle description is mandatory")
	@Size(min = 1, max = 1000)
	@Column(name = "DESCRIPTION_TX", length = 1000)
	private String descriptionText;

	@Embedded
	@Valid
	@NotNull(message = "Audit information is mandatory")
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
