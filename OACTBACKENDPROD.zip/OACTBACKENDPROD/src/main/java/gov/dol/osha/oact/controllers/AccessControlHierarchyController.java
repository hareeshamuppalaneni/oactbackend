package gov.dol.osha.oact.controllers;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.AccessControlHierarchyData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyQuery;
import gov.dol.osha.oact.services.AccessControlHierarchyService;

/**
 * Controller to handle Access Control Hierarchies
 *
 * @author Skietech Development Team
 */
@RestController
@RequestMapping("/access-control-hierarchies")
public class AccessControlHierarchyController {

	@Autowired
	private AccessControlHierarchyService hierarchyService;

	@GetMapping
	public List<AccessControlHierarchyData> getAccessControlHierarchyData(
			final AccessControlHierarchyQuery searchQuery) {

		return hierarchyService.getAccessControlHierarchyData(searchQuery);
	}

	@PostMapping
	public AccessControlHierarchyData createAccessControlHierarchy(
			@Valid @RequestBody final AccessControlHierarchyData hierarchyDetailsReq) {

		return hierarchyService.createAccessControlHierarchy(hierarchyDetailsReq);
	}

	@PutMapping
	public AccessControlHierarchyData updateAccessControlHierarchy(
			@Valid @RequestBody final AccessControlHierarchyData hierarchyDetailsReq) {

		return hierarchyService.updateAccessControlHierarchy(hierarchyDetailsReq);
	}

	@DeleteMapping(value = "/{hierarchyId}")
	public void deleteAccessControlHierarchy(@NotNull @PathVariable("hierarchyId") final Integer hierarchyId) {

		hierarchyService.deleteAccessControlHierarchy(hierarchyId);
	}

}
