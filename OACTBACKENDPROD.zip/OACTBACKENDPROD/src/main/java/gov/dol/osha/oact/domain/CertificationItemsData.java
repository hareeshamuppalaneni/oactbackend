package gov.dol.osha.oact.domain;

import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * This class is used to provide certification item data.
 *
 * @author Skietech Development Team
 */
@Data
public class CertificationItemsData {

	String applicationName;
	String officeName;
	String regionName;
	List<Map<String, String>> certificationItems;
}
