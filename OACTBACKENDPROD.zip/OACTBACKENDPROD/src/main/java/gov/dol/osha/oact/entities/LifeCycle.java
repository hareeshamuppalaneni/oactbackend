package gov.dol.osha.oact.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This support class has fields to record the life cycle of a
 * record.Information like when the record begin date and end date.
 *
 * @author Skietech Development Team
 */
@Builder(toBuilder = true)
@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class LifeCycle implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "BEGIN_EFFECTIVE_DT")
	private LocalDate beginEffectiveDate;

	@Column(name = "END_EFFECTIVE_DT")
	private LocalDateTime endEffectiveDate;
}
