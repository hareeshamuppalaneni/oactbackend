package gov.dol.osha.oact.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the CERTIIFCATION_ITEM_DTLS information
 *
 * @author Skietech Development Team
 */
@Table(name = " OACT_CTRL_CYCLE_ITEM")
@Entity
@Data
@RequiredArgsConstructor
public class CertificationItemDetails {

	@Id
	@GeneratedValue
	@Column(name = "CER_ITM_ID")
	private Integer cycleItemId;

	@NotBlank(message = "Item name is mandatory")
	@Size(min = 1, max = 100)
	@Column(name = "NM", length = 100)
	private String name;

	@Size(min = 0, max = 1000)
	@Column(name = "DESCRIPTION_TX", length = 1000)
	private String descriptionText;

	@OneToOne
	@JoinColumn(name = "FK_STATE_ID")
	private CycleState cycleState;

	@ManyToOne
	@NotNull(message = "Certification cycle id is mandatory")
	@JoinColumn(name = "FK_CC_ID")
	private CertificationCycle certificationCycle;

	@NotNull(message = "Due date is mandatory")
	@Column(name = "DUE_DT")
	private LocalDate dueDate;

	@Lob
	@NotNull(message = "Item details is mandatory")
	@Column(name = "ITEM_DTLS")
	private String itemDetails;

	@Size(min = 0, max = 320)
	@Column(name = "Office", length = 320)
	private String office;

	@Size(min = 0, max = 320)
	@Column(name = "RID", length = 320)
	private String rid;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
