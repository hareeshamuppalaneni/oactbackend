package gov.dol.osha.oact.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.CycleStateData;
import gov.dol.osha.oact.domain.searchQuery.CycleStateSearchQuery;
import gov.dol.osha.oact.entities.CycleState;
import gov.dol.osha.oact.repositories.CycleStateRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * This service class is used to implement the CRUD operation for cycle state
 * information
 *
 * @author Skietech Development Team
 */
@Validated
@Service
public class CycleSateService {

	@Autowired
	private CycleStateRepository cycleStateRepository;

	@Autowired
	private AuditInformation auditInformation;

	public List<CycleStateData> getCycleStateData(@NotNull final CycleStateSearchQuery searchQuery) {

		final CycleState cycleState = new CycleState();
		cycleState.setCycleStateId(searchQuery.getCycleStateId());
		cycleState.setStateName(searchQuery.getStateName());
		cycleState.setSubStateName(searchQuery.getSubStateName());

		final Example<CycleState> queryParameters = Example.of(cycleState);
		final List<CycleState> cycleStates = cycleStateRepository.findAll(queryParameters);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(cycleStates, "cycle states");

		final List<CycleStateData> cycleStateDataBag = new ArrayList<>();
		cycleStates.stream().forEach(indCycleState -> {

			final CycleStateData cycleStateData = new CycleStateData();
			BeanUtils.copyProperties(indCycleState, cycleStateData);
			cycleStateData.setAuditData(auditInformation.getAuditData(indCycleState.getAuditData()));
			cycleStateDataBag.add(cycleStateData);
		});

		return cycleStateDataBag;
	}

	public CycleStateData createCycleStateData(@NotNull CycleStateData cycleStateDataReq) {

		final CycleState cycleState = new CycleState();
		BeanUtils.copyProperties(cycleStateDataReq, cycleState);
		cycleState.setAuditData(
				auditInformation.setCreatorAuditData(cycleStateDataReq.getAuditData().getLastModifiedUserId()));
		cycleState.setLifeCycleData(auditInformation.setCreateLifeCycle());
		cycleStateRepository.save(cycleState);
		return cycleStateDataReq;
	}

	public CycleStateData updateCycleStateData(@NotNull CycleStateData cycleStateDataReq) {

		OSHACommonValidations.updateServiceInputValidation(cycleStateDataReq.getCycleStateId(),
				cycleStateDataReq.getAuditData().getLockControlNumber());

		final CycleState cycleState = getCycleStateById(cycleStateDataReq.getCycleStateId());
		OSHACommonValidations.safeLockControlNumber(cycleStateDataReq.getAuditData().getLockControlNumber(),
				cycleState.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(cycleStateDataReq, cycleState);
		cycleState.setAuditData(
				auditInformation.setUpdateAuditData(cycleStateDataReq.getAuditData(), cycleState.getAuditData()));
		cycleStateRepository.save(cycleState);
		return cycleStateDataReq;
	}

	public void deleteCycleStateData(@NotNull Integer cycleStateId) {

		cycleStateRepository.delete(getCycleStateById(cycleStateId));
	}

	private CycleState getCycleStateById(Integer cycleStateId) {

		final Optional<CycleState> cycleStateOpt = cycleStateRepository.findById(cycleStateId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				cycleStateOpt.isEmpty() ? null : cycleStateOpt.get(), "cycle state");
		return cycleStateOpt.get();
	}

}
