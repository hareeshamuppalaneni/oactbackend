package gov.dol.osha.oact.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import gov.dol.osha.oact.entities.CertificationItemDetails;

/**
 * Repository interface for {@link CertificationItemDetails} instances. Provides
 * basic CRUD operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface CertifactionItemDetailsRepossitory extends JpaRepository<CertificationItemDetails, Integer> {

	List<CertificationItemDetails> findByOfficeIgnoreCase(String officeName);

	List<CertificationItemDetails> findByCertificationCycleCertificationCycleId(int cycleId);

	
	List<CertificationItemDetails> findByCertificationCycleCertificationCycleIdAndCycleStateCycleStateId(Integer cycleId,Integer stateId);

	
	
}
