package gov.dol.osha.oact.services;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

import gov.dol.osha.oact.domain.CertificationItemsData;
import gov.dol.osha.oact.entities.AccessControlHierarchyPOC;
import gov.dol.osha.oact.entities.CertificationCycle;
import gov.dol.osha.oact.entities.CertificationItemDetails;
import gov.dol.osha.oact.entities.CycleState;
import gov.dol.osha.oact.entities.LifeCycle;
import gov.dol.osha.oact.entities.OSHAUser;
import gov.dol.osha.oact.repositories.CertifactionCycleRepository;
import gov.dol.osha.oact.repositories.CertifactionItemDetailsRepossitory;
import gov.dol.osha.oact.repositories.CycleStateRepository;
import gov.dol.osha.oact.repositories.OSHAUserRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.utils.EmailNotificationService;
import gov.dol.osha.oact.validation.OSHACommonValidations;
import lombok.extern.slf4j.Slf4j;

/**
 * This service class is used for file uploading processes
 *
 * @author Skietech Development Team
 *
 */
@Slf4j
@Component
public class FileUploadProcess {

	private static final String DATE_FORMAT = "MMM d, yyyy";

	@Autowired
	Environment env;

	@Autowired
	private CertifactionItemDetailsRepossitory itemDetailsRepository;

	@Autowired
	private AuditInformation auditInformation;

	@Autowired
	private CycleStateRepository cycleStateRepository;

	@Autowired
	private OSHAUserRepository userRepository;

	@Autowired
	private CertifactionCycleRepository cycleRepository;

	@Autowired
	private AccessControlHierarchyServicePOC pocService;

	@Autowired
	private AccessControlHierarchyService acCycleService;

	@Autowired
	private EmailNotificationService emailService;

	@Transactional
	public CertificationItemsData processUploadedFile(MultipartFile file, Integer cycleId, String userId) {

		Optional<CertificationCycle> certificationCycle = cycleRepository.findById(cycleId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				certificationCycle.isEmpty() ? null : certificationCycle.get(), "Cycle");

		Set<String> subAcctEmails = new HashSet<>();
		Set<String> acctEmails = new HashSet<>();
		for (AccessControlHierarchyPOC indpocData : certificationCycle.get().getAccessControlHierarchy()
				.getAcHierarchyPOCBag()) {
			if (indpocData.getSubAccountManager() != null
					&& StringUtils.isNotBlank(indpocData.getSubAccountManager().getEmailAddressText())) {

				subAcctEmails.add(indpocData.getSubAccountManager().getEmailAddressText());

			}

			if (indpocData.getAccountManager() != null
					&& StringUtils.isNotBlank(indpocData.getAccountManager().getEmailAddressText())) {

				acctEmails.add(indpocData.getAccountManager().getEmailAddressText());

			}
		}
		String applicationName = "";
		List<CertificationItemDetails> existingCycleItems = itemDetailsRepository
				.findByCertificationCycleCertificationCycleId(cycleId);

		if (CollectionUtils.isNotEmpty(existingCycleItems)) {
			applicationName = existingCycleItems.get(0).getCertificationCycle().getDescriptionText();
			existingCycleItems.forEach(cycleItem -> {
				final LifeCycle lifeCycleData = cycleItem.getLifeCycleData();
				lifeCycleData.setEndEffectiveDate(LocalDateTime.now());
				cycleItem.setLifeCycleData(lifeCycleData);

			});
			itemDetailsRepository.saveAll(existingCycleItems);
		}

		CertificationItemsData outItems = new CertificationItemsData();
		List<Map<String, String>> dataList = new ArrayList<>();
		try {

			File convFile = new File(file.getOriginalFilename());
			FileOutputStream fos = new FileOutputStream(convFile);
			fos.write(file.getBytes());
			fos.close();

			Workbook wb = WorkbookFactory.create(convFile);
			// Get sheet with the given name "Sheet1"
			Sheet sheet = wb.getSheetAt(0);
			Iterator<Row> itr = sheet.rowIterator();
			Map<String, List<String>> myMap = new LinkedHashMap<>();

			int rowHeaderCount = 0;

			// populate map with headers and empty list
			if (itr.hasNext()) {
				Row row = itr.next();
				Iterator<Cell> headerIterator = row.cellIterator();
				while (headerIterator.hasNext()) {
					Cell cell = headerIterator.next();
					if (null != cell) {
						myMap.put(getHeaderCellValue(cell), new ArrayList<>());
					}
					++rowHeaderCount;
				}
			}

			Iterator<List<String>> columnsIterator = null;
			// populate lists
			int rowcount = 0;
			while (itr.hasNext()) {
				// get the list iterator every row to start from first list
				columnsIterator = myMap.values().iterator();
				Row row = itr.next();
				if (isEmptyRow(row)) {
					continue;
				}
				rowcount = rowcount + 1;
				for (int i = 0; i <= rowHeaderCount - 1; i++) {
					Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
					if (null != cell) {
						columnsIterator.next().add(getCellValue(cell));
					}
				}
			}
			dataList = flatenMap(myMap, rowcount);

			int itemCount = 1;
			for (Map<String, String> indData : dataList) {
				createCycleItems(certificationCycle.get(), indData, userId, itemCount, acctEmails, subAcctEmails);
				itemCount++;
			}

			if (CollectionUtils.isNotEmpty(dataList)) {

				String emailEvent = "ACCOUNTMGR";
				String emailToBeSent = String.join(", ", acctEmails);
				if (subAcctEmails != null && subAcctEmails.size() > 0) {

					emailEvent = "SUBACCOUNTMGR";
					emailToBeSent = String.join(", ", subAcctEmails);
				}

				Map<String, String> inMap = new HashMap<>();
				inMap.put("$cycleName$", certificationCycle.get().getName());
				inMap.put("$applicationName$",
						certificationCycle.get().getAccessControlHierarchy().getDescriptionText());
				inMap.put("$dueDate$", certificationCycle.get().getDueDate().toString());

				emailService.sendEmail(emailToBeSent, inMap, emailEvent);

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		outItems.setCertificationItems(dataList);
		outItems.setApplicationName(applicationName);
		outItems.setOfficeName("OfficeName");
		outItems.setRegionName("regionname");
		return outItems;
	}

	@Transactional
	public void createCycleItems(CertificationCycle certificationCycle, Map<String, String> item, String userId,
			int itemCount, Set<String> acctEmails, Set<String> subAcctEmails) {

		final CertificationItemDetails certificationItemDetails = new CertificationItemDetails();
		certificationItemDetails.setCertificationCycle(certificationCycle);

		CycleState cycleState = cycleStateRepository.findByStateName("With Account Manager");

		if (subAcctEmails != null && subAcctEmails.size() > 0) {
			cycleState = cycleStateRepository.findByStateName("With SubAccount Manager");

		}
		if (null != cycleState) {

			CycleState cycleStateItem = cycleStateRepository.findByStateName("Under Review");
			certificationItemDetails.setCycleState(cycleStateItem);
		}
		final OSHAUser oshaUser = userRepository.findByLoginId(userId);
		certificationItemDetails.setAuditData(
				auditInformation.setCreatorAuditData(oshaUser != null ? oshaUser.getOshaUserId() : 10001));
		certificationItemDetails.setLifeCycleData(auditInformation.setCreateLifeCycle());
		certificationItemDetails.setDueDate(certificationCycle.getDueDate());
		certificationItemDetails.setName(certificationCycle.getName() + "_Item" + itemCount);
		if (null != item) {
			Gson gsonObj = new Gson();
			certificationItemDetails.setItemDetails(gsonObj.toJson(item));
			certificationItemDetails.setOffice(MapUtils.getString(item, "officeName"));
			certificationItemDetails.setRid(MapUtils.getString(item, "UserID"));
		}
		certificationCycle.setCycleState(cycleState);
		certificationCycle.setFAttestedBy(null);
		certificationCycle.setIAttestedBy(null);
		certificationCycle.setIAttestedTS(null);
		certificationCycle.setFAttestedTS(null);

		cycleRepository.save(certificationCycle);
		itemDetailsRepository.save(certificationItemDetails);

		// @NotNull
		// AccessControlHierarchyPOCQuery pocquery = new
		// AccessControlHierarchyPOCQuery();
		// pocquery.setParentHierarchyId(certificationCycle.getAccessControlHierarchy().getAccessControlHierarchyId());
		// List<AccessControlHierarchyPOCData> pocDataList =
		// pocService.getAccessControlHierarchyPOCData(pocquery);
		/*
		 * String emailToBeSent =
		 * pocDataList.get(0).getAccountManager().getEmailAddressText(); if (null !=
		 * pocDataList.get(0).getSubaccountManager()) { emailToBeSent = emailToBeSent +
		 * "," + pocDataList.get(0).getSubaccountManager().getEmailAddressText(); }
		 */
		/*
		 * final AccessControlHierarchy hierarchy = acCycleService
		 * .getHierarchyDataById(certificationCycle.getAccessControlHierarchy().
		 * getAccessControlHierarchyId());
		 *
		 * Map<String, String> inMap = new HashMap<String, String>();
		 * inMap.put("$cycleName$", certificationCycle.getName());
		 * inMap.put("$applicationName$", hierarchy.getDescriptionText());
		 * inMap.put("$dueDate$", certificationCycle.getDueDate().toString());
		 *
		 * emailService.sendEmail(emailToBeSent,inMap,emailEvent);
		 */

	}

	private List<Map<String, String>> flatenMap(Map<String, List<String>> myMap, int rowcount2) {

		Iterator<Map.Entry<String, List<String>>> itr = myMap.entrySet().iterator();

		Map<String, String> indvMap = new LinkedHashMap<>();
		List<Map<String, String>> itemList = new ArrayList<>();
		int rowCount = 0;

		for (int j = 0; j < rowcount2; j++) {

			itr = myMap.entrySet().iterator();
			indvMap = new LinkedHashMap<>();
			while (itr.hasNext()) {

				Map.Entry<String, List<String>> entry = itr.next();
				String value = entry.getValue().size() == 0 ? "" : entry.getValue().get(j);
				indvMap.put(entry.getKey(), value);
				rowCount = rowCount++;
			}
			itemList.add(indvMap);
		}
		return itemList;
	}

	private static String getCellValue(Cell cell) {

		switch (cell.getCellType()) {
		case STRING: // field that represents string cell type
			return cell.getStringCellValue().trim().equals("") ? "?"
					: StringUtils.replace(cell.getStringCellValue(), "\n", "");
		case NUMERIC: // field that represents number cell type
			if (DateUtil.isCellDateFormatted(cell)) {
				DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
				return dateFormat.format(cell.getDateCellValue());
			} else {
				return Double.toString(cell.getNumericCellValue());
			}

		case BLANK:
			return " ";
		default:
			return cell.getDateCellValue() == null ? "?" : StringUtils.trim(cell.getDateCellValue().toString());
		}
	}

	private static String getHeaderCellValue(Cell cell) {

		switch (cell.getCellType()) {
		case STRING: // field that represents string cell type
			return cell.getStringCellValue().trim().equals("") ? "?"
					: StringUtils.uncapitalize(StringUtils.deleteWhitespace(StringUtils
							.substringBefore(StringUtils.replace(cell.getStringCellValue(), "\n", ""), "[")));
		case NUMERIC: // field that represents number cell type
			return Double.toString(cell.getNumericCellValue());
		case BLANK:
			return " ";
		default:
			return cell.getDateCellValue() == null ? "?" : StringUtils.trim(cell.getDateCellValue().toString());
		}
	}

	public String uploadedFile(MultipartFile file) {
		String fileNameBase = "";
		try {
			fileNameBase = UUID.randomUUID() + "_" + file.getOriginalFilename();
			File convFile = new File(env.getProperty("file.temp.location") + fileNameBase);
			FileOutputStream fos = new FileOutputStream(convFile);
			fos.write(file.getBytes());
			fos.close();
		} catch (Exception e) {
			log.error(e.getLocalizedMessage());
		}
		return fileNameBase;
	}

	private boolean isEmptyRow(Row row) {
		boolean isEmptyRow = true;
		for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
			Cell cell = row.getCell(cellNum);
			if (cell != null && cell.getCellType() != CellType.BLANK && StringUtils.isNotBlank(cell.toString())) {
				isEmptyRow = false;
			}
		}
		return isEmptyRow;
	}

}
