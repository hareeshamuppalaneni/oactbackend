package gov.dol.osha.oact.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.OSHAUserData;
import gov.dol.osha.oact.domain.OSHAUserRoleResponse;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserRoleQuery;
import gov.dol.osha.oact.services.OSHAUserRoleService;
import gov.dol.osha.oact.services.OSHAUserService;

/**
 * Controller to provide logged in user information
 *
 * @author Skietech Development Team
 */
@RequestMapping("/who-am-i")
@RestController
public class WhoAmIController {

	@Autowired
	OSHAUserService oshaSrvc;

	@Autowired
	OSHAUserRoleService oshaRoleSrvc;

	/**
	 * Service is used to logged in user information.
	 *
	 * @return - user information
	 */
	@GetMapping
	public OSHAUserRoleResponse getUserDataInformation(String identifier) {

		OSHAUserData outUserData = oshaSrvc.getOSHAUserDataByEmail(identifier);
		OSHAUserRoleQuery roleQuery = new OSHAUserRoleQuery();
		roleQuery.setUserId(outUserData.getOshaUserId());

		OSHAUserRoleResponse ourResponse = oshaRoleSrvc.getOSHAUserRoleData(roleQuery);
		ourResponse.setUserInformation(outUserData);
		return ourResponse;
	}
}
