package gov.dol.osha.oact.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.AccessControlHierarchyData;
import gov.dol.osha.oact.domain.AuditData;
import gov.dol.osha.oact.domain.CycleCollectionData;
import gov.dol.osha.oact.domain.CycleData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyQuery;
import gov.dol.osha.oact.entities.StandardCycle;
import gov.dol.osha.oact.repositories.StandardCycleRepository;
import gov.dol.osha.oact.services.AccessControlHierarchyService;
import gov.dol.osha.oact.services.CertifcationCycleService;

@RestController
@RequestMapping("/loadCycles")
public class OACTAsyncController {

	@Autowired
	private CertifcationCycleService certificationCycleService;

	@Autowired
	private StandardCycleRepository stndCycleRepository;

	@Autowired
	private AccessControlHierarchyService achSrvc;

	@GetMapping
	public ResponseEntity<String> loadApplicationCycle() {

		final StandardCycle stndCycle = stndCycleRepository.getCurrentStandardCyle();

		final AccessControlHierarchyQuery hierarchyQuery = new AccessControlHierarchyQuery();
		hierarchyQuery.setOrganizationType("APPLICATION");
		final List<AccessControlHierarchyData> listOfApps = achSrvc.getAccessControlHierarchyData(hierarchyQuery);
		final List<CycleData> cycleDataBag = new ArrayList<>();

		listOfApps.stream().forEach(indApps -> {

			final CycleData cycleData = new CycleData();
			cycleData.setCycleStateId(stndCycle.getStndCycleId());
			cycleData.setCycleStartDate(stndCycle.getLifeCycleData().getBeginEffectiveDate());
			cycleData.setCycleDueDate(stndCycle.getLifeCycleData().getEndEffectiveDate().toLocalDate());
			cycleData.setCycleName(stndCycle.getDescriptionText());
			cycleData.setCycleHirerchyId(indApps.getAccessControlHierarchyId());
			cycleDataBag.add(cycleData);

		});

		final CycleCollectionData cycDataReq = new CycleCollectionData();
		cycDataReq.setCycleDataBag(cycleDataBag);
		AuditData batchAudit = new AuditData();
		batchAudit.setLastModifiedUserId(123456);
		batchAudit.setLockControlNumber(0);

		cycDataReq.setAuditData(batchAudit);
		certificationCycleService.createAccessControlCycleData(cycDataReq);
		return new ResponseEntity<>("Sucessfully Loaded", HttpStatus.CREATED);
	}

}
