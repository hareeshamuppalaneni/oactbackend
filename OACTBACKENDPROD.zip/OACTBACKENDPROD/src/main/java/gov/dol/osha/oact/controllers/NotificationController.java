package gov.dol.osha.oact.controllers;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Example;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.AccessControlHierarchyPOCData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlCycleQuery;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyPOCQuery;
import gov.dol.osha.oact.entities.AccessControlHierarchy;
import gov.dol.osha.oact.entities.CertificationCycle;
import gov.dol.osha.oact.entities.CertificationItemDetails;
import gov.dol.osha.oact.repositories.CertifactionCycleRepository;
import gov.dol.osha.oact.repositories.CertifactionItemDetailsRepossitory;
import gov.dol.osha.oact.services.AccessControlHierarchyServicePOC;
import gov.dol.osha.oact.utils.ConvertDataToExcelFile;
import gov.dol.osha.oact.utils.EmailNotificationService;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * Controller to provide logged in user information
 *
 * @author Skietech Development Team
 */
@RequestMapping("/notify")
@RestController
public class NotificationController {

	@Autowired
	private EmailNotificationService emailNotification;

	@Autowired
	private ConvertDataToExcelFile excelFile;

	@Autowired
	private CertifactionCycleRepository acCycleRepository;

	@Autowired
	private AccessControlHierarchyServicePOC pocService;

	@Autowired
	private CertifactionItemDetailsRepossitory itemDetailsRepository;

	/**
	 * Notify Cycle Reminder
	 *
	 * @return - user information
	 */
	@PostMapping("/cycle")
	public ResponseEntity<String> notifyCycle(@RequestBody List<Integer> cycleIDs) {

		OSHACommonValidations.validateCollection(cycleIDs, "Mandatory input cycle Identifers are missing");
		if (CollectionUtils.isNotEmpty(cycleIDs)) {

			for (Integer indvCycle : cycleIDs) {
				final CertificationCycle accessControlCycle = new CertificationCycle();
				AccessControlCycleQuery searchQuery = new AccessControlCycleQuery();
				accessControlCycle.setCertificationCycleId(indvCycle);

				final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
				accessControlHierarchy.setAccessControlHierarchyId(searchQuery.getAccessControlHierarchyId());
				accessControlCycle.setAccessControlHierarchy(accessControlHierarchy);
				accessControlCycle.setName(searchQuery.getName());

				final Example<CertificationCycle> queryParameters = Example.of(accessControlCycle);
				final List<CertificationCycle> accessControlCycleBag = acCycleRepository.findAll(queryParameters);
				OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(accessControlCycleBag, "cerfication cycle");

				@NotNull
				AccessControlHierarchyPOCQuery pocquery = new AccessControlHierarchyPOCQuery();
				pocquery.setParentHierarchyId(
						accessControlCycleBag.get(0).getAccessControlHierarchy().getAccessControlHierarchyId());
				List<AccessControlHierarchyPOCData> pocDataList = pocService.getAccessControlHierarchyPOCData(pocquery);

				String emailToBeSent = pocDataList.get(0).getCertCoOrdinator().getEmailAddressText();
				Map<String, String> inMap = new HashMap<>();
				inMap.put("$cycleName$", accessControlCycleBag.get(0).getName());

				inMap.put("$applicationName$", accessControlCycleBag.get(0).getAccessControlHierarchy().getName());

				inMap.put("$dueDate$", accessControlCycleBag.get(0).getDueDate().toString());

				// emailService.sendEmail(emailToBeSent,inMap,"CYCLEINIT");

			}
		}
		return new ResponseEntity<>("Sucessfully Notified", HttpStatus.OK);
	}

	/**
	 * Notify Cycle Reminder
	 *
	 * @return - user information
	 */
	@PostMapping("/cycle-item")
	public ResponseEntity<String> notifyCycleItem(@RequestBody List<Integer> cycleItemIDs) {

		OSHACommonValidations.validateCollection(cycleItemIDs, "Mandatory input cycle Identifers are missing");
		if (CollectionUtils.isNotEmpty(cycleItemIDs)) {

			for (Integer indvItem : cycleItemIDs) {

				Optional<CertificationItemDetails> cycleItem = itemDetailsRepository.findById(indvItem);

				@NotNull
				AccessControlHierarchyPOCQuery pocquery = new AccessControlHierarchyPOCQuery();
				pocquery.setParentHierarchyId(cycleItem.get().getCertificationCycle().getAccessControlHierarchy()
						.getAccessControlHierarchyId());
				List<AccessControlHierarchyPOCData> pocDataList = pocService.getAccessControlHierarchyPOCData(pocquery);

				String emailToBeSent = pocDataList.get(0).getCertCoOrdinator().getEmailAddressText();
				Map<String, String> inMap = new HashMap<>();
				inMap.put("$cycleName$", cycleItem.get().getCertificationCycle().getName());

				inMap.put("$itemName$", cycleItem.get().getName());

				// emailService.sendEmail(emailToBeSent,inMap,"CYCLEITEM");

			}

		}
		return new ResponseEntity<>("Sucessfully Notified", HttpStatus.OK);
	}

	@GetMapping("/email")
	public void emailTest() {

		Map<String, String> inMap = new HashMap<>();
		inMap.put("$cycleName$", "TestCycle");

		inMap.put("$applicationName$", "TestApplication");
		emailNotification.sendEmail("mahesh.kankanala@skietech.com", inMap, "CYCLEINIT");
	}

	@GetMapping(value = "/excel", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamResource> excelTest(@RequestParam Integer cycleId) throws IOException {

		return excelFile.writeDataToExcel(cycleId);

	}

}
