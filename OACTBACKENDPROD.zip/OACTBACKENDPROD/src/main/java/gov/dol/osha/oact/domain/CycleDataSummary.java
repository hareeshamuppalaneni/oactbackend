package gov.dol.osha.oact.domain;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;

@Data
public class CycleDataSummary {

	private Integer cycleId;
	private LocalDate cycleStartDate;
	private LocalDate cycleDueDate;
	private String cycleName;
	private Integer cycleHirerchyPocId;
	private CycleStateData cycleStateData;
	private List<CertificationItemDetailsSummary> itemData;
}
