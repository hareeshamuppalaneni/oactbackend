package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(NON_NULL)
public class CertificationItemEdits {

	@NotBlank(message = "Cycle ID is mandatory")
	private Integer cycleItemId;

	private String reviewComments;
	@NotBlank(message = "Review Status is mandatory")
	private String reviewStatus;
	@NotNull(message = "Edit Only Flag is mandatory (True or False)")
	Boolean editOnly;

}
