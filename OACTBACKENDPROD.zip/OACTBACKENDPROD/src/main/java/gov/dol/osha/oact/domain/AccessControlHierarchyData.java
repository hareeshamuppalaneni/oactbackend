package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used to provide Access Control Hierarchy data.
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class AccessControlHierarchyData {

	private Integer accessControlHierarchyId;

	@NotBlank(message = "Access control hierarchy name is mandatory")
	@Size(min = 1, max = 100)
	private String name;

	@Size(min = 0, max = 1000)
	private String descriptionText;

	@Size(min = 0, max = 1000)
	private String organizationType;

	@NotNull(message = "Parent access control hierarchy id is mandatory")
	private Integer parentAccessControlHierarchyId;

	private List<AccessControlHierarchyPOCData> hierarchyPOCBag;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;

}
