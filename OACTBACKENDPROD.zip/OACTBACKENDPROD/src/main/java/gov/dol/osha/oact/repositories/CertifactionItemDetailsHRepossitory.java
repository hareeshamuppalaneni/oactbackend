package gov.dol.osha.oact.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import gov.dol.osha.oact.entities.CertificationItemDetails;
import gov.dol.osha.oact.entities.CertificationItemDetailsH;

/**
 * Repository interface for {@link CertificationItemDetails} instances. Provides
 * basic CRUD operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface CertifactionItemDetailsHRepossitory extends JpaRepository<CertificationItemDetailsH, Integer> {

	List<CertificationItemDetailsH> findByOfficeIgnoreCase(String officeName);

	List<CertificationItemDetailsH> findByCertificationCycleCertificationCycleId(int cycleId);
	
	List<CertificationItemDetailsH> findByCycleItemId_OrderByLifeCycleDataEndEffectiveDateDesc(int cycleId);



}
