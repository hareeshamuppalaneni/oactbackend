package gov.dol.osha.oact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * The main entry point and configuration of the application. The Spring
 * ApplicationContext configuration is triggered by the @SpringBootApplication
 * annotation and automatically pulls in all spring elements in this packages
 * and its sub package.
 *
 * @author Skietech Development Team
 *
 */
@SpringBootApplication
public class OshaServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(OshaServicesApplication.class, args);
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*").allowedMethods("GET", "POST", "PUT", "DELETE")
						.allowedHeaders("*");
			}
		};
	}

}
