package gov.dol.osha.oact.domain;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class CycleCollectionData {

	private List<CycleData> cycleDataBag;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;

	private List<String> errorMessage;
}
