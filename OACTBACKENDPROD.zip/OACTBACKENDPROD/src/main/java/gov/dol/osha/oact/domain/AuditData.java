package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This support class has fields required to set the audit information.
 * Information like who created the record and the optimistic locking
 * information.
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class AuditData {

	@NotNull(message = "Last modified user id mandatory")
	private Integer lastModifiedUserId;

	private int lockControlNumber;
}
