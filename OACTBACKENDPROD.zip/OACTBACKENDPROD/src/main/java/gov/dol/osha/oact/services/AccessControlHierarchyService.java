package gov.dol.osha.oact.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.AccessControlHierarchyData;
import gov.dol.osha.oact.domain.AccessControlHierarchyPOCData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyQuery;
import gov.dol.osha.oact.entities.AccessControlHierarchy;
import gov.dol.osha.oact.repositories.AccessControlHierarchyRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

@Validated
@Service
public class AccessControlHierarchyService {

	@Autowired
	private AccessControlHierarchyRepository hierarchyRepository;

	@Autowired
	private AuditInformation auditInformation;

//	public Map<String, String> getAccessControlHierarchyDataRecursive(@NotNull final Integer identifier) {
//
//		Map<String, String> outMap = new ConcurrentHashMap<String, String>();
//
//		AccessControlHierarchyQuery qryHData = new AccessControlHierarchyQuery();
//		qryHData.setAccessControlHierarchyId(identifier);
//		List<AccessControlHierarchyData> outHList = getAccessControlHierarchyData(qryHData);
//
//		boolean isParentExist = false;
//		outMap.put(outHList.get(0).getOrganizationType().toLowerCase(), outHList.get(0).getName().toLowerCase());
//
//		if (outHList.get(0).getParentAccessControlHierarchyId() != 0) {
//			isParentExist = true;
//
//			while (isParentExist) {
//				qryHData.setAccessControlHierarchyId(outHList.get(0).getParentAccessControlHierarchyId());
//				outHList = getAccessControlHierarchyData(qryHData);
//				outMap.put(outHList.get(0).getOrganizationType().toLowerCase(),
//						outHList.get(0).getName().toLowerCase());
//				if (outHList.get(0).getParentAccessControlHierarchyId() == 0) {
//					isParentExist = false;
//				}
//			}
//		}
//
//		return outMap;
//	}

	public List<AccessControlHierarchyData> getAccessControlHierarchyData(
			@NotNull final AccessControlHierarchyQuery hierarchyQuery) {

		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		accessControlHierarchy.setAccessControlHierarchyId(hierarchyQuery.getAccessControlHierarchyId());
		accessControlHierarchy.setParentAccessControlHierarchyId(hierarchyQuery.getParentAccessControlHierarchyId());
		accessControlHierarchy.setOrganizationType(hierarchyQuery.getOrganizationType());
		accessControlHierarchy.setName(hierarchyQuery.getName());

		final Example<AccessControlHierarchy> queryParameters = Example.of(accessControlHierarchy);
		final List<AccessControlHierarchy> accessControlHierarchies = hierarchyRepository.findAll(queryParameters);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(accessControlHierarchies, "hierarchy");

		final List<AccessControlHierarchyData> accessControlHierarchyDetails = new ArrayList<>();

		accessControlHierarchies.stream().forEach(hierarchyData -> {

			AccessControlHierarchyData accessControlHierarchyData = new AccessControlHierarchyData();
			BeanUtils.copyProperties(hierarchyData, accessControlHierarchyData);
			accessControlHierarchyData.setAuditData(auditInformation.getAuditData(hierarchyData.getAuditData()));

			final List<AccessControlHierarchyPOCData> hierarchyPOCBag = new ArrayList<>();
			hierarchyData.getAcHierarchyPOCBag().stream().forEach(indPocData -> {

				final AccessControlHierarchyPOCData pocData = new AccessControlHierarchyPOCData();
				BeanUtils.copyProperties(indPocData, pocData);
				hierarchyPOCBag.add(pocData);
			});

			accessControlHierarchyData.setHierarchyPOCBag(hierarchyPOCBag);
			accessControlHierarchyDetails.add(accessControlHierarchyData);
		});

		return accessControlHierarchyDetails;
	}

	public AccessControlHierarchyData createAccessControlHierarchy(
			@NotNull AccessControlHierarchyData hierarchyDataReq) {

		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		BeanUtils.copyProperties(hierarchyDataReq, accessControlHierarchy);
		accessControlHierarchy.setAuditData(
				auditInformation.setCreatorAuditData(hierarchyDataReq.getAuditData().getLastModifiedUserId()));
		accessControlHierarchy.setLifeCycleData(auditInformation.setCreateLifeCycle());
		hierarchyRepository.save(accessControlHierarchy);
		return hierarchyDataReq;
	}

	public AccessControlHierarchyData updateAccessControlHierarchy(
			@NotNull AccessControlHierarchyData hierarchyDataReq) {

		OSHACommonValidations.updateServiceInputValidation(hierarchyDataReq.getAccessControlHierarchyId(),
				hierarchyDataReq.getAuditData().getLockControlNumber());

		final AccessControlHierarchy accessControlHierarchy = getHierarchyDataById(
				hierarchyDataReq.getAccessControlHierarchyId());
		OSHACommonValidations.safeLockControlNumber(hierarchyDataReq.getAuditData().getLockControlNumber(),
				accessControlHierarchy.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(hierarchyDataReq, accessControlHierarchy);
		accessControlHierarchy.setAuditData(auditInformation.setUpdateAuditData(hierarchyDataReq.getAuditData(),
				accessControlHierarchy.getAuditData()));
		hierarchyRepository.save(accessControlHierarchy);
		return hierarchyDataReq;
	}

	public void deleteAccessControlHierarchy(@NotNull Integer accessControlHierarchyId) {

		hierarchyRepository.delete(getHierarchyDataById(accessControlHierarchyId));
	}

	public AccessControlHierarchy getHierarchyDataById(Integer hierarchyId) {

		final Optional<AccessControlHierarchy> accessControlHierarchyOpt = hierarchyRepository.findById(hierarchyId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				accessControlHierarchyOpt.isEmpty() ? null : accessControlHierarchyOpt.get(), "Hierarchy");

		return accessControlHierarchyOpt.get();
	}

}
