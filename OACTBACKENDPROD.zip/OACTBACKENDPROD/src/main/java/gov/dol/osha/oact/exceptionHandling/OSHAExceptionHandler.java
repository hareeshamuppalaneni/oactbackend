package gov.dol.osha.oact.exceptionHandling;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.METHOD_NOT_ALLOWED;

import javax.persistence.EntityNotFoundException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import lombok.extern.slf4j.Slf4j;

/**
 * Set of handler methods that are automatically injected into all controller
 * {@link org.springframework.web.bind.annotation.RestController} methods.  *  
 *
 * @author Skietech Development Team  
 */
@Slf4j
@ControllerAdvice
public class OSHAExceptionHandler {

	/**
	 * Handler for OSHA Customer Exceptions.
	 *
	 * @param exception - OSHAException
	 * @return - Error message and Status Code
	 */

	@SuppressWarnings("rawtypes")
	@ExceptionHandler(OSHAException.class)
	public ResponseEntity handleOSHAException(final OSHAException exception) {

		return exception.getResponseEntity();
	}

	/**
	 * Handler for requested input field database validation failed.
	 *
	 * @param exception - ConstraintViolationException
	 * @return - Error message
	 */

	@ResponseBody
	@ResponseStatus(BAD_REQUEST)
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ErrorMessage handleConstraintViolationException(final DataIntegrityViolationException exception) {

		if (exception.getCause() instanceof ConstraintViolationException) {

			String message = StringUtils.substringBefore(exception.getCause().getCause().getLocalizedMessage(), ";");

			return new ErrorMessage(message);
		}

		return new ErrorMessage(exception.getCause().getLocalizedMessage());
	}

	/**
	 * Handler for required input field.
	 *
	 * @param exception - MethodArgumentNotValidException
	 * @return - Error message
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(BAD_REQUEST)
	@ResponseBody
	public ErrorMessage handleMethodArgumentNotValidException(final MethodArgumentNotValidException exception) {

		final FieldError fieldError = exception.getBindingResult().getFieldError();
		final String message = fieldError.getDefaultMessage() + " (" + fieldError.getField() + ")";
		return new ErrorMessage(message);
	}

	/**
	 * Handler for input value miss match
	 *
	 * @param exception - InvalidFormatException
	 * @return - Error message
	 */
	@ExceptionHandler(HttpMessageNotReadableException.class)
	@ResponseStatus(BAD_REQUEST)
	@ResponseBody
	public ErrorMessage handleInvalidFormatException(final HttpMessageNotReadableException exception) {

		final String message = exception.getMessage();
		return new ErrorMessage(message);
	}

	/**
	 * Handler for input request parameter is missing
	 *
	 * @param exception - MissingServletRequestParameterException
	 * @return - Error message
	 */
	@ExceptionHandler(MissingServletRequestParameterException.class)
	@ResponseStatus(BAD_REQUEST)
	@ResponseBody
	protected ErrorMessage handleMissingServletRequestParameterException(
			final MissingServletRequestParameterException exception) {

		return new ErrorMessage(exception.getParameterName() + " parameter is missing");
	}

	/**
	 * Handler for Data foreign key violation.
	 *
	 * @param exception - InvalidDataAccessApiUsageException
	 * @return - Error messages along with status code
	 */
	@ExceptionHandler(InvalidDataAccessApiUsageException.class)
	@ResponseStatus(BAD_REQUEST)
	@ResponseBody
	public ErrorMessage handleInvalidDataAccessApiUsageException(final InvalidDataAccessApiUsageException exception) {

		return new ErrorMessage("Please enter valid reference/parent key data :" + exception.getLocalizedMessage());
	}

	/**
	 * Handler for unsupported service URLs.
	 *
	 * @param exception - HttpRequestMethodNotSupportedException
	 * @return - Error messages along with status code
	 */
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	@ResponseStatus(METHOD_NOT_ALLOWED)
	@ResponseBody
	public ErrorMessage handleHttpRequestMethodNotSupportedException(
			final HttpRequestMethodNotSupportedException exception) {

		return new ErrorMessage(exception.getLocalizedMessage()
				+ ".Please check the service defination in SWAGGER or contact OSHA support team");
	}

	/**
	 * Handler for the foreign key value is not found.
	 *
	 * @param exception - EntityNotFoundException
	 * @return - Error messages along with status code
	 */
	@ExceptionHandler(EntityNotFoundException.class)
	@ResponseStatus(BAD_REQUEST)
	@ResponseBody
	public ErrorMessage handleEntityNotFoundException(final EntityNotFoundException exception) {

		return new ErrorMessage(exception.getLocalizedMessage());
	}

	/**
	 * Handler for remaining runtime exceptions.
	 *
	 * @param exception - Exception
	 * @return - Error message
	 */

	@ExceptionHandler(Exception.class)
	@ResponseStatus(INTERNAL_SERVER_ERROR)
	@ResponseBody
	public ErrorMessage handleAllExceptions(final Exception exception) {

		log.error(exception.getLocalizedMessage(),exception);

		return new ErrorMessage("Application system error. Please contact OSHA support team.");
	}

}
