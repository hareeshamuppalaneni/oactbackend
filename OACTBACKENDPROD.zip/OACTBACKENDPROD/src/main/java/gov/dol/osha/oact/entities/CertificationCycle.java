package gov.dol.osha.oact.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Entity capturing the ACCESS_CONTROL_CYCLE information
 *
 * @author Skietech Development Team
 */
@Table(name = "OACT_CTRL_CYCLE")
@Entity
@Getter
@Setter
@RequiredArgsConstructor
public class CertificationCycle {

	@Id
	@GeneratedValue
	@Column(name = "CC_ID")
	private Integer certificationCycleId;

	@NotBlank(message = "Access control cycle name is mandatory")
	@Size(min = 1, max = 100)
	@Column(name = "NM", length = 100)
	private String name;

	@Size(min = 0, max = 1000)
	@Column(name = "DESCRIPTION_TX", length = 1000)
	private String descriptionText;

	@Column(name = "DUE_DT")
	private LocalDate dueDate;

	@Column(name = "START_DT")
	private LocalDate cycleStartDate;

	@Column(name = "end_DT")
	private LocalDate cycleEndDate;

	@OneToOne
	@JoinColumn(name = "FK_ACH_ID")
	@NotNull(message = "Access control hirerachy id is mandatory")
	private AccessControlHierarchy accessControlHierarchy;

//	@Column(name = "FK_ACH_POC_ID")
//	@NotNull(message = "Access control hirerachy id is mandatory")
//	private Integer accessControlPocHierarchyId;

	@Column(name = "FISCAL_YEAR")
	private String fiscalYear;

	@Column(name = "I_ATTESTED_TS")
	private LocalDateTime iAttestedTS;

	@Column(name = "F_ATTESTED_TS")
	private LocalDateTime fAttestedTS;

	@Column(name = "I_ATTESTED_BY")
	private Integer iAttestedBy;

	@Column(name = "F_ATTESTED_BY")
	private Integer fAttestedBy;

	@Column(name = "ATTESTATION_FILE_NM")
	private String attestationFileName;

	@Column(name = "EXCEL_FILE_NM")
	private String excelFileName;

	@Column(name = "FISCAL_QTR")
	private String fiscalQuater;

	@OneToOne
	@JoinColumn(name = "FK_CYCLE_STATE_ID")
	@NotNull(message = "Associate Cycle State is mandatory")
	private CycleState cycleState;

	@OneToMany(mappedBy = "certificationCycle")
	private List<CertificationItemDetails> itemDetailsBag;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;

}
