package gov.dol.osha.oact.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.OSHAUserData;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserSearchQuery;
import gov.dol.osha.oact.entities.OSHAUser;
import gov.dol.osha.oact.repositories.OSHAUserRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * This service class is used to implement the CRUD operation for OSHA user
 * information
 *
 * @author Skietech Development Team
 *
 */
@Validated
@Service
public class OSHAUserService {

	@Autowired
	private OSHAUserRepository oshaUserRepository;

	@Autowired
	private AuditInformation auditInformation;

	public List<OSHAUserData> getOSHAUserDataByQueryParameter(@NotNull final OSHAUserSearchQuery searchQuery) {

		final OSHAUser oshaUser = new OSHAUser();
		oshaUser.setEmployeeNumber(searchQuery.getEmployeeNumber());
		oshaUser.setOshaUserId(searchQuery.getOshaUserId());
		oshaUser.setFirstName(searchQuery.getFirstName());
		oshaUser.setLastName(searchQuery.getLastName());
		oshaUser.setLoginId(searchQuery.getLoginIdentifier());
		oshaUser.setEmailAddressText(searchQuery.getEmail());

		final Example<OSHAUser> queryParameters = Example.of(oshaUser);
		final List<OSHAUser> users = oshaUserRepository.findAll(queryParameters);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(users, "user role");
		final List<OSHAUserData> oshaUsersData = new ArrayList<>();

		users.stream().forEach(user -> {

			final OSHAUserData oshaUserData = new OSHAUserData();
			BeanUtils.copyProperties(user, oshaUserData);
			oshaUserData.setAuditData(auditInformation.getAuditData(user.getAuditData()));
			oshaUsersData.add(oshaUserData);
		});

		return oshaUsersData;
	}

	public OSHAUserData getOSHAUserDataByEmail(@NotNull final String identifier) {

		final OSHAUserData oshaUser = new OSHAUserData();

		final OSHAUser user = oshaUserRepository.findByEmailAddressTextIgnoreCase(identifier.trim().toLowerCase());
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(user, "user Information");
		BeanUtils.copyProperties(user, oshaUser);
		return oshaUser;
	}

	public OSHAUserData createUserData(@NotNull OSHAUserData oshaUserDataReq) {

		final OSHAUser oshaUser = new OSHAUser();
		BeanUtils.copyProperties(oshaUserDataReq, oshaUser);
		oshaUser.setAuditData(
				auditInformation.setCreatorAuditData(oshaUserDataReq.getAuditData().getLastModifiedUserId()));
		oshaUser.setLifeCycleData(auditInformation.setCreateLifeCycle());
		oshaUserRepository.save(oshaUser);
		return oshaUserDataReq;
	}

	public OSHAUserData updateUserData(@NotNull OSHAUserData oshaUserDataReq) {

		OSHACommonValidations.updateServiceInputValidation(oshaUserDataReq.getOshaUserId(),
				oshaUserDataReq.getAuditData().getLockControlNumber());

		final OSHAUser oshaUser = getOSHAUserById(oshaUserDataReq.getOshaUserId());
		OSHACommonValidations.safeLockControlNumber(oshaUserDataReq.getAuditData().getLockControlNumber(),
				oshaUser.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(oshaUserDataReq, oshaUser);
		oshaUser.setAuditData(
				auditInformation.setUpdateAuditData(oshaUserDataReq.getAuditData(), oshaUser.getAuditData()));
		oshaUserRepository.save(oshaUser);
		return oshaUserDataReq;
	}

	public void deleteUserData(@NotNull Integer userId) {

		oshaUserRepository.delete(getOSHAUserById(userId));
	}

	public OSHAUser getOSHAUserById(Integer userId) {

		final Optional<OSHAUser> oshaUserOpt = oshaUserRepository.findById(userId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(oshaUserOpt.isEmpty() ? null : oshaUserOpt.get(),
				"user");
		return oshaUserOpt.get();
	}

	public String getUserFullNameById(Integer userId) {

		String userFullName = " ";

		final Optional<OSHAUser> oshaUserOpt = oshaUserRepository.findById(userId);

		if (oshaUserOpt.isPresent()) {

			userFullName = oshaUserOpt.get().getFirstName()
					+ StringUtils.defaultString(oshaUserOpt.get().getMiddleName(), " ")
					+ oshaUserOpt.get().getLastName();
		}

		return userFullName;
	}

}
