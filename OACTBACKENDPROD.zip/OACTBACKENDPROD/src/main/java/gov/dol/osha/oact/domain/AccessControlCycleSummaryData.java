package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide Access control cycle data.
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class AccessControlCycleSummaryData {

	private Integer certificationCycleId;

	@NotBlank(message = "Access control cycle name is mandatory")
	@Size(min = 1, max = 100)
	private String name;

	@NotNull(message = "Due data is mandatory")
	private LocalDate dueDate;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;
}
