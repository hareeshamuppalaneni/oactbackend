package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used to provide Access Control Hierarchy data.
 *
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class AccessControlHierarchyPOCFlowSummary {

	private Integer accessControlHierarchyPocId;

	private String systemOwner;

	private String systemPoc;

	private String certCoOrdinator;

	private String accountManager;

	private String accountManagerOfc;

	private String subaccountManager;

	private String applicationName;
	private String applicationCode;

	private String systemName;

	private String agency;

	private int subAccountManagerCount;
}
