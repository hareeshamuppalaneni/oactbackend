package gov.dol.osha.oact.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the OSHA_USER information
 *
 * @author Skietech Development Team
 */
@Table(name = "OACT_USER")
@Entity
@Data
@RequiredArgsConstructor
public class OSHAUser {

	@Id
	@GeneratedValue
	@Column(name = "OSHA_USER_ID")
	private Integer oshaUserId;

	@Size(min = 0, max = 20)
	@Column(name = "EMPLOYEE_ID", length = 6)
	private String employeeNumber;

	@Size(min = 0, max = 60)
	@Column(name = "FIRST_NM", length = 60)
	private String firstName;

	@Size(min = 0, max = 60)
	@Column(name = "LAST_NM", length = 60)
	private String lastName;

	@Size(min = 0, max = 60)
	@Column(name = "MIDDLE_NM", length = 60)
	private String middleName;

	@Size(min = 0, max = 320)
	@Column(name = "LOGIN_ID", length = 320)
	private String loginId;

	@Size(min = 0, max = 180)
	@Column(name = "FULL_NM", length = 180)
	private String fullName;

	@Email
	@Size(min = 0, max = 320)
	@Column(name = "EMAIL_ADDRESS_TX", length = 320)
	private String emailAddressText;

	@Column(name = "LAST_LOGIN_TS")
	private LocalDateTime lastLoginDateTime;

	@Size(min = 0, max = 320)
	@Column(name = "Office", length = 320)
	private String office;

	@Size(min = 0, max = 320)
	@Column(name = "RID", length = 320)
	private String rid;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
