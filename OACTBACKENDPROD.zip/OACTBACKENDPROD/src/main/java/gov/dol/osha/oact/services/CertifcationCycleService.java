package gov.dol.osha.oact.services;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Example;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.AccessControlCycleBulkData;
import gov.dol.osha.oact.domain.AccessControlCycleData;
import gov.dol.osha.oact.domain.AccessControlCycleSummaryData;
import gov.dol.osha.oact.domain.AccessControlHierarchyData;
import gov.dol.osha.oact.domain.AccessControlHierarchyPOCData;
import gov.dol.osha.oact.domain.AccessControlHierarchyPOCFlowSummary;
import gov.dol.osha.oact.domain.CertificationItemDetailsData;
import gov.dol.osha.oact.domain.CycleCollectionData;
import gov.dol.osha.oact.domain.CycleDataResponse;
import gov.dol.osha.oact.domain.CycleStateData;
import gov.dol.osha.oact.domain.OSHAUserData;
import gov.dol.osha.oact.domain.OSHAUserRoleResponse;
import gov.dol.osha.oact.domain.StandardUserRoleData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlCycleQuery;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyPOCQuery;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyQuery;
import gov.dol.osha.oact.domain.searchQuery.CertificationItemDetailsSearchQuery;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserRoleQuery;
import gov.dol.osha.oact.entities.AccessControlHierarchy;
import gov.dol.osha.oact.entities.Audit;
import gov.dol.osha.oact.entities.CertificationCycle;
import gov.dol.osha.oact.entities.CertificationItemDetails;
import gov.dol.osha.oact.entities.CycleState;
import gov.dol.osha.oact.exceptionHandling.ErrorMessage;
import gov.dol.osha.oact.exceptionHandling.OSHAException;
import gov.dol.osha.oact.repositories.CertifactionCycleRepository;
import gov.dol.osha.oact.repositories.CertifactionItemDetailsRepossitory;
import gov.dol.osha.oact.repositories.CycleStateRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.utils.EmailNotificationService;
import gov.dol.osha.oact.validation.OSHACommonValidations;
import lombok.extern.slf4j.Slf4j;

/**
 * This service class is used to implement the CRUD operation for certification
 * cycle information.
 *
 * @author Skietech Development Team
 *
 */
@Slf4j
@Validated
@Service
public class CertifcationCycleService {

	@Autowired
	private CertifactionCycleRepository acCycleRepository;

	@Autowired
	private AccessControlHierarchyService acCycleService;

	@Autowired
	private AuditInformation auditInformation;

	@Autowired
	private CertifactionItemDetailsRepossitory itemRepository;

	@Autowired
	private EmailNotificationService emailService;

	@Autowired
	private CycleStateRepository cycleStateRepository;

	@Autowired
	private OSHAUtils oshaUtils;

	@Autowired
	private OSHAUserService userSrvc;

	@Autowired
	private AccessControlHierarchyServicePOC pocService;

	@Autowired
	OSHAUserRoleService oshaRoleSrvc;

	@Autowired
	private Environment env;
	@Lazy
	@Autowired
	private CertificationItemDetailsService itemService;

	public List<CycleDataResponse> getAccessControlCycleData(@NotNull final AccessControlCycleQuery searchQuery) {

		final CertificationCycle accessControlCycle = new CertificationCycle();
		accessControlCycle.setCertificationCycleId(searchQuery.getAccessControlCycleId());

		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		accessControlHierarchy.setAccessControlHierarchyId(searchQuery.getAccessControlHierarchyId());
		accessControlCycle.setAccessControlHierarchy(accessControlHierarchy);
		accessControlCycle.setName(searchQuery.getName());

		final Example<CertificationCycle> queryParameters = Example.of(accessControlCycle);
		final List<CertificationCycle> accessControlCycleBag = acCycleRepository.findAll(queryParameters);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(accessControlCycleBag, "cerfication cycle");

		final List<CycleDataResponse> accessControlCycleDataBag = new ArrayList<>();

		accessControlCycleBag.stream().forEach(acCycleData -> {

			final CycleDataResponse cycleDataResponse = new CycleDataResponse();
			BeanUtils.copyProperties(acCycleData, cycleDataResponse);
			cycleDataResponse.setAuditData(auditInformation.getAuditData(acCycleData.getAuditData()));
			Period period = Period.between(LocalDate.now(), acCycleData.getDueDate());
			cycleDataResponse.setDaysTillDueDate(period.getDays());

			final CycleStateData cycleStateData = new CycleStateData();
			BeanUtils.copyProperties(acCycleData.getCycleState(), cycleStateData);
			cycleDataResponse.setCycleSate(cycleStateData);

			final AccessControlHierarchyPOCQuery pocquery = new AccessControlHierarchyPOCQuery();
			pocquery.setParentHierarchyId(acCycleData.getAccessControlHierarchy().getAccessControlHierarchyId());
			final List<AccessControlHierarchyPOCData> pocDataList = pocService
					.getAccessControlHierarchyPOCData(pocquery);

			AccessControlHierarchyPOCFlowSummary posData = new AccessControlHierarchyPOCFlowSummary();
			HashSet<String> identifierList = new HashSet<>();
			boolean constructResponse = false;
			HashSet<String> accountMangerSet = new HashSet<>();
			HashSet<String> coOrdSet = new HashSet<>();
			HashSet<String> asystemPocSet = new HashSet<>();
			HashSet<String> systemOwnerSet = new HashSet<>();
			HashSet<String> subccountMgrList = new HashSet<>();
			pocDataList.stream().forEach(indpocData -> {

				accountMangerSet.add(indpocData.getAccountManager().getFullName());
				coOrdSet.add(indpocData.getCertCoOrdinator().getFullName());
				asystemPocSet.add(indpocData.getSystemPoc().getFullName());
				systemOwnerSet.add(indpocData.getSystemOwner().getFullName());

				identifierList.add(StringUtils.lowerCase(indpocData.getAccountManager().getEmailAddressText()));
				identifierList.add(StringUtils.lowerCase(indpocData.getSystemPoc().getEmailAddressText()));
				identifierList.add(StringUtils.lowerCase(indpocData.getSystemOwner().getEmailAddressText()));
				identifierList.add(StringUtils.lowerCase(indpocData.getCertCoOrdinator().getEmailAddressText()));
				if (indpocData.getSubaccountManager() != null
						&& StringUtils.isNotBlank(indpocData.getSubaccountManager().getEmailAddressText())) {
					identifierList.add(StringUtils.lowerCase(indpocData.getSubaccountManager().getEmailAddressText()));
					subccountMgrList
							.add(StringUtils.lowerCase(indpocData.getSubaccountManager().getEmailAddressText()));
				}
				posData.setApplicationName(acCycleData.getAccessControlHierarchy().getDescriptionText());

				posData.setApplicationCode(acCycleData.getAccessControlHierarchy().getName());
				posData.setAgency("OSHA");

				final AccessControlHierarchyQuery accessControlQry = new AccessControlHierarchyQuery();
				accessControlQry.setAccessControlHierarchyId(
						acCycleData.getAccessControlHierarchy().getParentAccessControlHierarchyId());
				List<AccessControlHierarchyData> hrerchyList = acCycleService
						.getAccessControlHierarchyData(accessControlQry);
				if (CollectionUtils.isNotEmpty(hrerchyList)) {
					posData.setSystemName(hrerchyList.get(0).getName());
				}
				posData.setSubAccountManagerCount(subccountMgrList.size());

			});

			if (StringUtils.isNotBlank(searchQuery.getEmail())) {
				if (identifierList.contains(searchQuery.getEmail().toLowerCase())) {
					constructResponse = true;
				}
			}

			if (constructResponse) {
				posData.setAccountManager(
						accountMangerSet.stream().map(Object::toString).collect(Collectors.joining(",")));
				posData.setSystemOwner(systemOwnerSet.stream().map(Object::toString).collect(Collectors.joining(",")));
				posData.setSystemPoc(asystemPocSet.stream().map(Object::toString).collect(Collectors.joining(",")));
				posData.setCertCoOrdinator(coOrdSet.stream().map(Object::toString).collect(Collectors.joining(",")));
				cycleDataResponse.setPocData(posData);

				/*
				 * Gson gson = new Gson();
				 *
				 * final List<CertificationItemDetailsData> itemDetailsBag = new ArrayList<>();
				 * acCycleData.getItemDetailsBag().stream().forEach(indItemData -> {
				 *
				 * final CertificationItemDetailsData itemDetailsData = new
				 * CertificationItemDetailsData(); BeanUtils.copyProperties(indItemData,
				 * itemDetailsData);
				 *
				 * itemDetailsData.setCycleItemDetails(gson.fromJson(indItemData.getItemDetails(
				 * ), Map.class)); itemDetailsBag.add(itemDetailsData); });
				 *
				 *
				 * cycleDataResponse.setItemDetails(itemDetailsBag);
				 */
				accessControlCycleDataBag.add(cycleDataResponse);
			}

		});

		return accessControlCycleDataBag;
	}

	public AccessControlCycleData createAccessControlCycleData(@NotNull AccessControlCycleData accessControlCycleReq) {

		final CertificationCycle certificationCycle = new CertificationCycle();
		BeanUtils.copyProperties(accessControlCycleReq, certificationCycle);

		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		accessControlHierarchy.setAccessControlHierarchyId(accessControlCycleReq.getAccessControlHierarchyId());
		certificationCycle.setAccessControlHierarchy(accessControlHierarchy);

		certificationCycle.setAuditData(
				auditInformation.setCreatorAuditData(accessControlCycleReq.getAuditData().getLastModifiedUserId()));
		certificationCycle.setLifeCycleData(auditInformation.setCreateLifeCycle());

		final CycleState cycleState = new CycleState();
		cycleState.setCycleStateId(accessControlCycleReq.getCycleStateId());
		certificationCycle.setCycleState(cycleState);
		acCycleRepository.save(certificationCycle);

		return accessControlCycleReq;
	}

	public AccessControlCycleSummaryData updateAccessControlCycleData(
			@NotNull AccessControlCycleSummaryData accessControlCycleReq) {

		OSHACommonValidations.updateServiceInputValidation(accessControlCycleReq.getCertificationCycleId(),
				accessControlCycleReq.getAuditData().getLockControlNumber());

		final CertificationCycle certificationCycle = getCertificationCycleById(
				accessControlCycleReq.getCertificationCycleId());

		OSHACommonValidations.safeLockControlNumber(accessControlCycleReq.getAuditData().getLockControlNumber(),
				certificationCycle.getAuditData().getLockControlNumber());

		BeanUtils.copyProperties(accessControlCycleReq, certificationCycle);
		certificationCycle.setAuditData(auditInformation.setUpdateAuditData(accessControlCycleReq.getAuditData(),
				certificationCycle.getAuditData()));

		acCycleRepository.save(certificationCycle);

		return accessControlCycleReq;
	}

	@Transactional
	public AccessControlCycleBulkData bulkUpdateAccessControlCycleData(
			@NotNull AccessControlCycleBulkData cycleBulkReq) {

		final List<CertificationCycle> certificationCycleBag = new ArrayList<>();

		for (Integer cycleId : cycleBulkReq.getCycleIdBag()) {

			final CertificationCycle certificationCycle = getCertificationCycleById(cycleId);
			certificationCycle.setName(cycleBulkReq.getName());
			certificationCycle.setDueDate(cycleBulkReq.getDueDate());
			certificationCycle.setAuditData(auditInformation.setUpdateAuditData(cycleBulkReq.getAuditData(),
					certificationCycle.getAuditData()));
		}

		acCycleRepository.saveAll(certificationCycleBag);
		return cycleBulkReq;
	}

	public void deleteAccessControlCycleData(@NotNull Integer certCycleId) {

		acCycleRepository.delete(getCertificationCycleById(certCycleId));
	}

	private CertificationCycle getCertificationCycleById(Integer certCycleId) {

		final Optional<CertificationCycle> certificationCycleOpt = acCycleRepository.findById(certCycleId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				certificationCycleOpt.isEmpty() ? null : certificationCycleOpt.get(), "certification cycle");

		return certificationCycleOpt.get();
	}

	@Transactional
	public CycleCollectionData createAccessControlCycleData(@NotNull CycleCollectionData cycDataReq) {

		final Audit audit = auditInformation.setCreatorAuditData(cycDataReq.getAuditData().getLastModifiedUserId());
		final List<String> errorMessage = new ArrayList<>();

		cycDataReq.getCycleDataBag().stream().forEach(indCycleReq -> {

			final CertificationCycle certificationCycle = new CertificationCycle();
			final AccessControlHierarchy hierarchy = acCycleService
					.getHierarchyDataById(indCycleReq.getCycleHirerchyId());

			String reviewStus = null;

			if (StringUtils.isNotBlank(indCycleReq.getFileRefernceId())) {
				reviewStus = "Under Review";
			} else {
				reviewStus = "Init";
			}

			final CycleState cycleState = cycleStateRepository.findByStateName(reviewStus);

			if (null != cycleState) {
				certificationCycle.setCycleState(cycleState);
			}

			final CertificationCycle cycleData = acCycleRepository
					.findByAccessControlHierarchyAccessControlHierarchyId(indCycleReq.getCycleHirerchyId());

			if (cycleData != null) {
				errorMessage.add("Cycle already created for " + indCycleReq.getCycleHirerchyId());
			} else {
				certificationCycle.setCycleState(cycleState);
				certificationCycle.setAuditData(audit);
				certificationCycle.setCycleStartDate(indCycleReq.getCycleStartDate());
				certificationCycle.setDueDate(indCycleReq.getCycleDueDate());
				certificationCycle.setName(indCycleReq.getCycleName() + "_" + hierarchy.getName());
				certificationCycle.setAccessControlHierarchy(hierarchy);
				acCycleRepository.save(certificationCycle);

				// Send Email to appropriate folks

				final AccessControlHierarchyPOCQuery pocquery = new AccessControlHierarchyPOCQuery();
				pocquery.setParentHierarchyId(indCycleReq.getCycleHirerchyId());
				final List<AccessControlHierarchyPOCData> pocDataList = pocService
						.getAccessControlHierarchyPOCData(pocquery);

				String emailToBeSent = pocDataList.get(0).getCertCoOrdinator().getEmailAddressText();
				final Map<String, String> inMap = new HashMap<>();
				inMap.put("$cycleName$", certificationCycle.getName());
				inMap.put("$applicationName$", hierarchy.getDescriptionText());
				inMap.put("$dueDate$", indCycleReq.getCycleDueDate().toString());
				emailService.sendEmail(emailToBeSent, inMap, "CYCLEINIT");

				if (StringUtils.isNotBlank(indCycleReq.getFileRefernceId())) {

					final CertificationItemDetails certificationItemDetails = new CertificationItemDetails();
					certificationItemDetails.setAuditData(audit);
					certificationItemDetails.setCycleState(cycleState);
					certificationItemDetails.setCertificationCycle(certificationCycle);
					certificationItemDetails.setName(indCycleReq.getCycleName());
					certificationItemDetails.setDueDate(indCycleReq.getCycleDueDate());
					certificationItemDetails.setItemDetails(indCycleReq.getFileRefernceId());
					itemRepository.save(certificationItemDetails);
				}
			}
		});

		cycDataReq.setErrorMessage(errorMessage);
		return cycDataReq;
	}

	@Transactional
	public void attestation(@NotNull String emailId, @NotNull List<Integer> cycleIds) {

		for (Integer cycleId : cycleIds) {
			OSHACommonValidations.validateString(cycleIds.toString(), "Mandatory Input cycleID is missing");
			final CertificationCycle acCycleData = getCertificationCycleById(cycleId);

			final AccessControlHierarchyPOCQuery pocquery = new AccessControlHierarchyPOCQuery();
			pocquery.setParentHierarchyId(acCycleData.getAccessControlHierarchy().getAccessControlHierarchyId());

			final List<AccessControlHierarchyPOCData> pocDataList = pocService
					.getAccessControlHierarchyPOCData(pocquery);

			AccessControlHierarchyPOCFlowSummary posData = new AccessControlHierarchyPOCFlowSummary();
			boolean updateOn = false;
			boolean accountMgrEmail = false;
			boolean systemOwnerEmail = false;
			Integer acctMgrId = 0;
			Integer systemOwnerId = 0;
			Map<String, String> attestationDataMap = new ConcurrentHashMap<>();

			Date date = new Date();
			SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
			String stringDate = DateFor.format(date);
			attestationDataMap.put("$SYSTEM$", "OSHA");
			attestationDataMap.put("$DATE$", stringDate);
			attestationDataMap.put("$APPLICATION$", acCycleData.getAccessControlHierarchy().getDescriptionText());
			attestationDataMap.put("$ACCOUNTMGRTS$", acCycleData.getIAttestedTS() == null ? ""
					: acCycleData.getIAttestedTS().truncatedTo(ChronoUnit.SECONDS).toString().replace("T", " "));

			String sysOwnrEMail = "";
			String cordinatoorEmail = "";
			for (AccessControlHierarchyPOCData indpocData : pocDataList) {

				attestationDataMap.put("$CONTACT$", indpocData.getSystemPoc().getFullName());
				attestationDataMap.put("$PHONE$", "PHONE");
				attestationDataMap.put("$ACCOUNTMGR$", indpocData.getAccountManager().getFullName());
				attestationDataMap.put("$ACCEMAIL$", indpocData.getAccountManager().getEmailAddressText());

				if (StringUtils.equalsAnyIgnoreCase(indpocData.getAccountManager().getEmailAddressText(), emailId)) {
					accountMgrEmail = true;
					acctMgrId = indpocData.getAccountManager().getOshaUserId();

				}

				

					cordinatoorEmail = indpocData.getCertCoOrdinator().getEmailAddressText();

			

				if (StringUtils.equalsAnyIgnoreCase(indpocData.getSystemOwner().getEmailAddressText(), emailId)) {
					systemOwnerEmail = true;
					systemOwnerId = indpocData.getSystemOwner().getOshaUserId();
					attestationDataMap.put("$SYSTEMOWNR$", indpocData.getSystemOwner().getFullName());
					attestationDataMap.put("$SYSEMAIL$", indpocData.getSystemOwner().getEmailAddressText());
				}
				sysOwnrEMail = indpocData.getSystemOwner().getEmailAddressText();

			}

			if (accountMgrEmail || systemOwnerEmail) {

				CycleState syscycleState = cycleStateRepository.findByStateName("With System Owner");

				CycleState accMgrcycleState = cycleStateRepository.findByStateName("Pending Attestation");

				if (acCycleData.getCycleState().getStateName().trim().toLowerCase()
						.equals(syscycleState.getStateName().trim().toLowerCase())
						|| acCycleData.getCycleState().getStateName().toLowerCase()
								.equals(accMgrcycleState.getStateName().toLowerCase())) {

					if (acCycleData.getIAttestedTS() == null && acCycleData.getFAttestedTS() == null
							&& accountMgrEmail) {
						acCycleData.setIAttestedTS(LocalDateTime.now());
						attestationDataMap.put("$ACCOUNTMGRTS$",
								acCycleData.getIAttestedTS() == null ? ""
										: acCycleData.getIAttestedTS().truncatedTo(ChronoUnit.SECONDS).toString()
												.replace("T", " "));
						acCycleData.setIAttestedBy(acctMgrId);
						syscycleState = cycleStateRepository.findByStateName("With System Owner");
						acCycleData.setCycleState(syscycleState);
						updateOn = true;
						log.info(attestationDataMap.toString());
						String attestationFileName = oshaUtils.createAttestioPDF(attestationDataMap,
								acCycleData.getName(), acCycleData.getAccessControlHierarchy().getName(), "Intial");
						final AccessControlHierarchy hierarchy = acCycleService.getHierarchyDataById(
								acCycleData.getAccessControlHierarchy().getAccessControlHierarchyId());
						Map<String, String> inMap = new HashMap<>();
						inMap.put("$cycleName$", acCycleData.getName());
						inMap.put("$applicationName$", hierarchy.getDescriptionText());
						inMap.put("$dueDate$", acCycleData.getDueDate().toString());
						acCycleData.setAttestationFileName(attestationFileName);
						String emailToBeSent = sysOwnrEMail;
						emailService.sendEmail(emailToBeSent,inMap,"SYSOWNEREMAIL");

					}

					if (acCycleData.getIAttestedTS() != null && acCycleData.getFAttestedTS() == null
							&& systemOwnerEmail) {

						LocalDateTime currTime = LocalDateTime.now();
						String currentDateTime = currTime.truncatedTo(ChronoUnit.SECONDS).toString();
						acCycleData.setFAttestedTS(currTime);
						acCycleData.setFAttestedBy(systemOwnerId);
						syscycleState = cycleStateRepository.findByStateName("Completed");
						acCycleData.setCycleState(syscycleState);
						attestationDataMap.put("$SYSTEMOWNRTS$", currentDateTime.replace("T", " "));
						updateOn = true;
						log.info(attestationDataMap.toString());
						String attestationFileName = oshaUtils.createAttestioPDF(attestationDataMap,
								acCycleData.getName(), acCycleData.getAccessControlHierarchy().getName(), "Final");

						final AccessControlHierarchy hierarchy = acCycleService.getHierarchyDataById(
								acCycleData.getAccessControlHierarchy().getAccessControlHierarchyId());
						Map<String, String> inMap = new HashMap<>();
						inMap.put("$cycleName$", acCycleData.getName());
						inMap.put("$applicationName$", hierarchy.getDescriptionText());
						inMap.put("$dueDate$", acCycleData.getDueDate().toString());
						acCycleData.setAttestationFileName(attestationFileName);
						String emailToBeSent = sysOwnrEMail + "," + cordinatoorEmail
								+ (env.getProperty("CYCBER_EMAIL_ADDRESS") == null ? ""
										: env.getProperty("CYCBER_EMAIL_ADDRESS"));
						
						log.info("Cyber Email to be sent to"+ emailToBeSent);

						List<File> filesTobeAttached = new ArrayList<>();
						File attestationFile = new File(env.getProperty("ATTEST_FILE_LOC") + attestationFileName);
						filesTobeAttached.add(attestationFile);

						writeDataToExcel(cycleId);
						filesTobeAttached.add(new File(env.getProperty("ATTEST_FILE_LOC")
								+ attestationFileName.substring(0, attestationFileName.lastIndexOf("_")) + ".xlsx"));
						emailService.sendEmailWithAttachment(emailToBeSent, inMap, "SYSOWNERCOMP", filesTobeAttached);

					}
				} else {

					throw new OSHAException(BAD_REQUEST,
							new ErrorMessage("Current state of the Application is not qualified for Attestation"));
				}

				if (updateOn) {
					acCycleRepository.save(acCycleData);
				} else {
					throw new OSHAException(BAD_REQUEST,
							new ErrorMessage("Check the current state of the Cycle for the Attestation"));
				}

			} else {
				throw new OSHAException(BAD_REQUEST,
						new ErrorMessage("The user is not Authorized to Attest this Application"));
			}
		}

	}

	public List<ConcurrentHashMap<String, Object>> getAttestationData(@NotNull String email) {

		@NotNull
		AccessControlCycleQuery accessQuery = new AccessControlCycleQuery();
		accessQuery.setEmail(email);

		OSHAUserData userData = userSrvc.getOSHAUserDataByEmail(email);

		@NotNull
		OSHAUserRoleQuery roleQuery = new OSHAUserRoleQuery();

		roleQuery.setUserId(userData.getOshaUserId());

		OSHAUserRoleResponse ourResponse = oshaRoleSrvc.getOSHAUserRoleData(roleQuery);
		boolean accountMgr = false;
		for (StandardUserRoleData indvRole : ourResponse.getRoleInformation()) {

			if (indvRole.getStndUserRoleId().equals(303)) {
				accountMgr = true;
			}

		}

		List<CycleDataResponse> cycleReponse = getAccessControlCycleData(accessQuery);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(cycleReponse, "cerfication cycle");
		List<ConcurrentHashMap<String, Object>> outList = new ArrayList<>();

		for (CycleDataResponse indvResponse : cycleReponse) {

			if ((indvResponse.getCycleSate().getStateName().equals("Pending Attestation")
					|| indvResponse.getCycleSate().getStateName().equals("With System Owner"))) {

				if (indvResponse.getCycleSate().getStateName().equals("With System Owner") && accountMgr) {
					continue;
				}
				ConcurrentHashMap<String, Object> invMap = new ConcurrentHashMap<>();
				invMap.put("cycleId", indvResponse.getCertificationCycleId());
				invMap.put("applicationName", indvResponse.getPocData().getApplicationName());
				invMap.put("cycleName", indvResponse.getName());
				outList.add(invMap);
			}

		}

		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(outList, "No attestation data found");
		return outList;
	}

	public ResponseEntity<InputStreamResource> fetchAttestationPDF(@NotNull Integer cycleId) {

		ResponseEntity<InputStreamResource> streamSource = null;

		final Optional<CertificationCycle> accessControlCycle = acCycleRepository.findById(cycleId);

		CertificationCycle certCycle = accessControlCycle.get();

		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(certCycle, "cerfication cycle");
		String attestFileLoc = env.getProperty("ATTEST_FILE_LOC");

		return downloadFileFromMount(new File(attestFileLoc + certCycle.getAttestationFileName()));

	}

	private ResponseEntity<InputStreamResource> downloadFileFromMount(final File file) {

		try {

			if (file.exists()) {

				final byte[] fileContent = Files.readAllBytes(file.toPath());

				final InputStreamResource inputStreamResource = new InputStreamResource(
						new ByteArrayInputStream(fileContent));

				return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).body(inputStreamResource);

			} else {

				throw new OSHAException(BAD_REQUEST,

						new ErrorMessage("File is not available in store location"));

			}

		} catch (final IOException ex) {

			log.error(ex.getMessage(), ex);

			throw new OSHAException(BAD_REQUEST,
					new ErrorMessage("Exception occurred while loading the document from mount"));

		}

	}

	private void writeDataToExcel(Integer cycleId) {

		final CertificationItemDetailsSearchQuery searchQuery = new CertificationItemDetailsSearchQuery();
		searchQuery.setCycleId(cycleId);

		final List<CertificationItemDetailsData> itemDetailsBag = itemService.getCertificationItemDetails(searchQuery,
				null, null, false);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(itemDetailsBag, "item details");

		String reviewerName = acCycleRepository.findById(cycleId).get().getAccessControlHierarchy()
				.getAcHierarchyPOCBag().get(0).getAccountManager().getFullName();

		Date reviewDate = new Date();
		SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
		String stringDate = DateFor.format(reviewDate);

		final List<String[]> rowHeaders = new ArrayList<>();
		String headerComments = "Instructions: Please enter the information below for each account assigned to users, for general and privileged users. If a user has more "
				+ " than one account, please insert a separate row for each account. Use the Comments column to provide details to explain Review Results"
				+ " selection and/or explain any other results from the review. Ensure you review for consistency with access control policies, e.g. period "
				+ "of inactivity resulting in account being disabled: compare Last Login Date and Account status entries.";

		String[] headerLineOne = { "Agency", "OSHA", " ", headerComments };
		String[] headerLineTwo = { "Review Date", stringDate };
		String[] headerLineThree = { "Reviewer Name", reviewerName };
		String[] headerLineFour = { " " };
		String[] headerLineFive = { "Last Name", "First Name", "Middle Initial", "Agency", "Sub-Agency",
				"User Email Address", "UserID", "System Name", "User Type", "Account Type", "Account Creation Date",
				"Last Login Date", "Account Status", "Review Results", "Comments" };

		rowHeaders.add(headerLineOne);
		rowHeaders.add(headerLineTwo);
		rowHeaders.add(headerLineThree);
		rowHeaders.add(headerLineFour);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("CycleData");

		int headerCount = 0;
		for (String[] indHeader : rowHeaders) {

			Row headerRow = sheet.createRow(headerCount);
			if (headerCount == 3) {
				break;
			}
			for (int i = 0; i < indHeader.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(indHeader[i]);
				// cell.setCellStyle(headerCellStyle);
			}
			headerCount = headerCount + 1;
		}

		XSSFFont dataHeaderFont = workbook.createFont();
		dataHeaderFont.setFontName("Arial");
		dataHeaderFont.setFontHeightInPoints((short) 12);
		dataHeaderFont.setColor(IndexedColors.WHITE1.index);
		dataHeaderFont.setBold(true);

		CellStyle dataHeaderCellStyle = workbook.createCellStyle();
		dataHeaderCellStyle.setFillForegroundColor(IndexedColors.ROYAL_BLUE.index);
		dataHeaderCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		dataHeaderCellStyle.setWrapText(true);
		dataHeaderCellStyle.setFont(dataHeaderFont);

		Row headerRowFive = sheet.createRow(4);

		for (int i = 0; i < headerLineFive.length; i++) {
			Cell cell = headerRowFive.createCell(i);
			cell.setCellValue(headerLineFive[i]);
			cell.setCellStyle(dataHeaderCellStyle);
		}

		sheet.addMergedRegion(new CellRangeAddress(0, 2, 3, 14));
		sheet.setAutoFilter(new CellRangeAddress(4, 4, 0, 14));

		int rowNum = 5;

		String cycleName = "";
		String excelFileNameDest = env.getProperty("ATTEST_FILE_LOC");

		for (CertificationItemDetailsData itemDetails : itemDetailsBag) {
			cycleName = itemDetails.getName().substring(0, itemDetails.getName().lastIndexOf("_"));
			Map<String, String> itemsMap = itemDetails.getCycleItemDetails();
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "lastName"), " "));
			row.createCell(1).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "firstName"), " "));
			row.createCell(2)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "middleInitial"), " "));
			row.createCell(3).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "agency"), " "));
			row.createCell(4).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "subAgency"), " "));
			row.createCell(5)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "userEmailAddress"), " "));
			row.createCell(6).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "userId"), " "));
			row.createCell(7).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "systemName"), " "));
			row.createCell(8).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "userType"), " "));
			row.createCell(9).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "accountType"), " "));
			row.createCell(10)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "accountCreationDate"), " "));
			row.createCell(11)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "lastLoginDate"), " "));
			row.createCell(12)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "accountStatus"), " "));
			row.createCell(13)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "reviewResults"), " "));
			row.createCell(14).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "comments"), " "));
		}

		for (int i = 0; i < headerLineFive.length; i++) {
			sheet.autoSizeColumn(i);
		}

		try {
			// Write the workbook in file system
			excelFileNameDest = excelFileNameDest + cycleName + ".xlsx";
			FileOutputStream out = new FileOutputStream(new File(excelFileNameDest));
			workbook.write(out);
			out.close();

			workbook.close();
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		} finally {

		}

	}

}
