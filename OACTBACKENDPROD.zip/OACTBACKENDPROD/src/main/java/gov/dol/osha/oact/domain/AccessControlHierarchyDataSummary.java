package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used to provide Access Control Hierarchy data.
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class AccessControlHierarchyDataSummary {

	private Integer accessControlHierarchyId;

	private Integer parentAccessControlHierarchyId;

	private String name;

	private String descriptionText;

	private String organizationType;

}
