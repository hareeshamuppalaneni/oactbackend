package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide OSHA user roles data.
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class OSHAUserRoleData {

	private Integer oshaUserRoleId;

	@NotNull(message = "User id is mandatory")
	private Integer oshaUserId;

	@NotNull(message = "Role id is mandatory")
	private Integer userRoleId;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;

	@Valid
	@NotNull(message = "Primary Indicatoor is  ")
	private String primaryIndicator = "Y";
}
