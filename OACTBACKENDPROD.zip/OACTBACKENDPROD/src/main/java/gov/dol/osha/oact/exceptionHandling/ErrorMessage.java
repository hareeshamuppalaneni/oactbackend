package gov.dol.osha.oact.exceptionHandling;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * This class is user to provide error or warning messages.
 *
 * @author Skietech Development Team
 *
 */
@Data
@AllArgsConstructor
public class ErrorMessage {

	private String message;

}
