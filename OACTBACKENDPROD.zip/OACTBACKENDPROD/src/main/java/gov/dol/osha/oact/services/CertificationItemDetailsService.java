package gov.dol.osha.oact.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.google.gson.Gson;

import gov.dol.osha.oact.domain.CertificationItemDetailsData;
import gov.dol.osha.oact.domain.CertificationItemEdits;
import gov.dol.osha.oact.domain.CycleDataResponse;
import gov.dol.osha.oact.domain.CycleStateData;
import gov.dol.osha.oact.domain.OSHAUserData;
import gov.dol.osha.oact.domain.OSHAUserRoleResponse;
import gov.dol.osha.oact.domain.StandardUserRoleData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlCycleQuery;
import gov.dol.osha.oact.domain.searchQuery.CertificationItemDetailsSearchQuery;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserRoleQuery;
import gov.dol.osha.oact.entities.AccessControlHierarchy;
import gov.dol.osha.oact.entities.Audit;
import gov.dol.osha.oact.entities.CertificationCycle;
import gov.dol.osha.oact.entities.CertificationItemDetails;
import gov.dol.osha.oact.entities.CertificationItemDetailsH;
import gov.dol.osha.oact.entities.CycleState;
import gov.dol.osha.oact.entities.LifeCycle;
import gov.dol.osha.oact.entities.OSHAUser;
import gov.dol.osha.oact.repositories.CertifactionCycleRepository;
import gov.dol.osha.oact.repositories.CertifactionItemDetailsHRepossitory;
import gov.dol.osha.oact.repositories.CertifactionItemDetailsRepossitory;
import gov.dol.osha.oact.repositories.CycleStateRepository;
import gov.dol.osha.oact.repositories.OSHAUserRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * This service class is used to implement the CRUD operation for certification
 * item details.
 *
 * @author Skietech Development Team
 */
@Validated
@Service
public class CertificationItemDetailsService {

	@Autowired
	private CertifactionItemDetailsRepossitory itemDetailsRepository;

	@Autowired
	private CertifactionItemDetailsHRepossitory itemDetailsHistRepository;
	@Autowired
	private CertifcationCycleService cycleSrvc;

	@Autowired
	private OSHAUserService userSrvc;

	@Autowired
	private CycleStateRepository cycleStateRepository;

	@Autowired
	private CertifactionCycleRepository cycleRepository;

	@Autowired
	private AccessControlHierarchyService acCycleService;

	@Autowired
	private AuditInformation auditInformation;

	@Autowired
	OSHAUserRoleService oshaRoleSrvc;
	
	@Autowired
	private OSHAUserRepository userRepository;

	public List<CertificationItemDetailsData> getCertificationItemDetails(
			@NotNull final CertificationItemDetailsSearchQuery searchQuery, CycleDataResponse cycle, String email,
			boolean subAccountMgr) {

		final CertificationItemDetails certificationItemDetails = new CertificationItemDetails();
		certificationItemDetails.setCycleItemId(searchQuery.getItemId());
		final CertificationCycle certificationCycle = new CertificationCycle();
		certificationCycle.setCertificationCycleId(searchQuery.getCycleId());
		certificationItemDetails.setCertificationCycle(certificationCycle);
		 List<CertificationItemDetails> itemBag  =  new ArrayList<CertificationItemDetails>();
		if (StringUtils.isNotBlank(searchQuery.getItemOffice()) && StringUtils.containsAnyIgnoreCase(searchQuery.getItemOffice(), ","))
		{
			List<String> officeLIst =  Arrays.asList(StringUtils.split(searchQuery.getItemOffice(),","));
			
			for (String indvOffice:officeLIst)
			{
				certificationItemDetails.setOffice(indvOffice.trim());
				final Example<CertificationItemDetails> queryParameters = Example.of(certificationItemDetails);
				
				final List<CertificationItemDetails> itemBagInv = itemDetailsRepository.findAll(queryParameters);
				itemBag.addAll(itemBagInv);
			}
			
		}
		else
		{
			certificationItemDetails.setOffice(searchQuery.getItemOffice());
			final Example<CertificationItemDetails> queryParameters = Example.of(certificationItemDetails);
			itemBag = itemDetailsRepository.findAll(queryParameters);
		}
	

		
		

		final List<CertificationItemDetails> itemDetails = itemBag.stream()
				.filter(item -> item.getLifeCycleData().getEndEffectiveDate() == null).collect(Collectors.toList());

		// OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(itemDetails, "item
		// details");
		Gson gson = new Gson();
		final List<CertificationItemDetailsData> itemDetailsDataBag = new ArrayList<>();
		itemDetails.stream().forEach(itemData -> {

			final CertificationItemDetailsData certificationItemDetailsData = new CertificationItemDetailsData();
			BeanUtils.copyProperties(itemData, certificationItemDetailsData);
			certificationItemDetailsData.setAuditData(auditInformation.getAuditData(itemData.getAuditData()));
			final CycleStateData cycleSateData = new CycleStateData();
			BeanUtils.copyProperties(itemData.getCycleState(), cycleSateData);
			certificationItemDetailsData.setCycleItemDetails(gson.fromJson(itemData.getItemDetails(), Map.class));
			boolean constructResponse = true;
			if (cycle != null && cycle.getPocData() != null) {
				certificationItemDetailsData.setPocData(cycle.getPocData());

			}

			certificationItemDetailsData.setCycleState(cycleSateData);
			certificationItemDetailsData.setCycleId(itemData.getCertificationCycle().getCertificationCycleId());
			if (constructResponse) {
				itemDetailsDataBag.add(certificationItemDetailsData);
			}

		});

		return itemDetailsDataBag;
	}

	public List<CertificationItemDetailsData> getCertificationItemDetailsByEmail(@NotNull final String email) {

		final List<CertificationItemDetailsData> itemDetailsDataBag = new ArrayList<>();
		final AccessControlCycleQuery cycleSrchQuery = new AccessControlCycleQuery();
		cycleSrchQuery.setEmail(email);

		List<CycleDataResponse> cycleResponse = cycleSrvc.getAccessControlCycleData(cycleSrchQuery);

		OSHAUserData userData = userSrvc.getOSHAUserDataByEmail(email);

		@NotNull
		OSHAUserRoleQuery roleQuery = new OSHAUserRoleQuery();

		roleQuery.setUserId(userData.getOshaUserId());

		OSHAUserRoleResponse ourResponse = oshaRoleSrvc.getOSHAUserRoleData(roleQuery);
		boolean subAccountMgr = false;
		boolean accountMgr = false;
		for (StandardUserRoleData indvRole : ourResponse.getRoleInformation()) {

			if (indvRole.getStndUserRoleId().equals(301) && ourResponse.getRoleInformation().size() == 1) {
				subAccountMgr = true;
			}

		}
		CycleState syscycleState = cycleStateRepository.findByStateName("With System Owner");
		for (CycleDataResponse cycle : cycleResponse) {

			if (syscycleState.getCycleStateId().equals(cycle.getCycleSate().getCycleStateId())) {

				continue;
			}

			if (!subAccountMgr && !StringUtils.containsAnyIgnoreCase(cycle.getPocData().getAccountManager(), userData.getFullName())) {
				continue;
			}
			@NotNull
			CertificationItemDetailsSearchQuery itemSrchQuery = new CertificationItemDetailsSearchQuery();
			itemSrchQuery.setCycleId(cycle.getCertificationCycleId());
			if (subAccountMgr) {
				itemSrchQuery.setItemOffice(userData.getOffice().trim());
			}

			itemDetailsDataBag.addAll(getCertificationItemDetails(itemSrchQuery, cycle, email, subAccountMgr));
		}

		return itemDetailsDataBag;
	}

	public CertificationItemDetailsData createCertificationItemDetails(
			@NotNull CertificationItemDetailsData itemDetailsDataReq) {

		final CertificationItemDetails certificationItemDetails = new CertificationItemDetails();
		BeanUtils.copyProperties(itemDetailsDataReq, certificationItemDetails);
		certificationItemDetails.setAuditData(
				auditInformation.setCreatorAuditData(itemDetailsDataReq.getAuditData().getLastModifiedUserId()));
		certificationItemDetails.setLifeCycleData(auditInformation.setCreateLifeCycle());
		final CycleState cycleSate = new CycleState();
		BeanUtils.copyProperties(itemDetailsDataReq.getCycleState(), cycleSate);
		certificationItemDetails.setCycleState(cycleSate);

		final CertificationCycle certificationCycle = new CertificationCycle();
		certificationCycle.setCertificationCycleId(itemDetailsDataReq.getCycleId());
		certificationItemDetails.setCertificationCycle(certificationCycle);
		itemDetailsRepository.save(certificationItemDetails);
		return itemDetailsDataReq;
	}

	public CertificationItemDetailsData updateCertificationItemDetails(
			@NotNull CertificationItemDetailsData itemDetailsDataReq) {

		OSHACommonValidations.updateServiceInputValidation(itemDetailsDataReq.getCycleItemId(),
				itemDetailsDataReq.getAuditData().getLockControlNumber());

		final CertificationItemDetails certificationItemDetails = getItemDetailsById(
				itemDetailsDataReq.getCycleItemId());
		OSHACommonValidations.safeLockControlNumber(itemDetailsDataReq.getAuditData().getLockControlNumber(),
				certificationItemDetails.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(itemDetailsDataReq, certificationItemDetails);
		certificationItemDetails.setAuditData(auditInformation.setUpdateAuditData(itemDetailsDataReq.getAuditData(),
				certificationItemDetails.getAuditData()));

		final CycleState cycleSate = new CycleState();
		BeanUtils.copyProperties(itemDetailsDataReq.getCycleState(), cycleSate);
		certificationItemDetails.setCycleState(cycleSate);

		final CertificationCycle certificationCycle = new CertificationCycle();
		certificationCycle.setCertificationCycleId(itemDetailsDataReq.getCycleId());
		certificationItemDetails.setCertificationCycle(certificationCycle);

		itemDetailsRepository.save(certificationItemDetails);
		return itemDetailsDataReq;
	}

	public void deleteCertificationItemDetails(@NotNull Integer itemDetailsId) {

		itemDetailsRepository.delete(getItemDetailsById(itemDetailsId));
	}

	private CertificationItemDetails getItemDetailsById(Integer itemDetailsId) {

		final Optional<CertificationItemDetails> itemDetailsOpt = itemDetailsRepository.findById(itemDetailsId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				itemDetailsOpt.isEmpty() ? null : itemDetailsOpt.get(), "item details");
		return itemDetailsOpt.get();
	}

	@Transactional
	public String editCertificationItemDetails(@NotNull List<CertificationItemEdits> itemDetailsEditReq,
			boolean undoFlag) {

		String outString = "Updated Successfully";

		OSHACommonValidations.validateCollection(itemDetailsEditReq, "Input Certification items are missing");

		Gson gson = new Gson();
		CertificationCycle certificationCycle = new CertificationCycle();
		Set<Integer> cycleIds = new HashSet<>();
		CertificationItemDetails dtls = new CertificationItemDetails();
		for (CertificationItemEdits indvUpdItm : itemDetailsEditReq) {

			final Optional<CertificationItemDetails> itemDetailsOpt = itemDetailsRepository
					.findById(indvUpdItm.getCycleItemId());

			if (itemDetailsOpt != null) {

				if (undoFlag) {
					CertificationItemDetailsH history = new CertificationItemDetailsH();
					history.setCycleItemId(indvUpdItm.getCycleItemId());
					final Example<CertificationItemDetailsH> queryParameters = Example.of(history);
					List<CertificationItemDetailsH> undoItemDetails = itemDetailsHistRepository
							.findAll(queryParameters);
					BeanUtils.copyProperties(undoItemDetails.get(0), dtls);
					final CycleState cycleState = cycleStateRepository.findByStateName("Under Review");
					final LifeCycle lifeCycleDataM = new LifeCycle();
					lifeCycleDataM.setBeginEffectiveDate(LocalDate.now());
					lifeCycleDataM.setEndEffectiveDate(null);
					dtls.setLifeCycleData(lifeCycleDataM);
					if (null != cycleState) {
						dtls.setCycleState(cycleState);
					}

				} else {
					OSHACommonValidations.validateString(indvUpdItm.getCycleItemId().toString(),
							"Cycle Item identifer cannnot be null");
					OSHACommonValidations.validateString(indvUpdItm.getReviewStatus(),
							"Review Status  cannnot be null");

					CertificationItemDetailsH historyItems = new CertificationItemDetailsH();

					dtls = itemDetailsOpt.get();
					BeanUtils.copyProperties(dtls, historyItems);

					final LifeCycle lifeCycleDataHist = historyItems.getLifeCycleData();
					lifeCycleDataHist.setEndEffectiveDate(LocalDateTime.now());
					historyItems.setLifeCycleData(lifeCycleDataHist);
					itemDetailsHistRepository.save(historyItems);
					itemDetailsHistRepository.flush();

					final CycleState cycleState = cycleStateRepository.findByStateName("Completed");
					dtls = itemDetailsOpt.get();
					if (null != cycleState) {
						final LifeCycle lifeCycleDataM = new LifeCycle();
						lifeCycleDataM.setBeginEffectiveDate(LocalDate.now());
						lifeCycleDataM.setEndEffectiveDate(null);
						dtls.setLifeCycleData(lifeCycleDataM);
						dtls.setCycleState(cycleState);
					}
				}

				certificationCycle = dtls.getCertificationCycle();
				cycleIds.add(certificationCycle.getCertificationCycleId());
				Map<String, String> itmDltMaps = gson.fromJson(dtls.getItemDetails(), Map.class);

				itmDltMaps.put("reviewResults", indvUpdItm.getReviewStatus());
				itmDltMaps.put("comments", indvUpdItm.getReviewComments());
				dtls.setItemDetails(gson.toJson(itmDltMaps));
				// dtls.setCycleState(null);
				// if(indvUpdItm.getEditOnly()!=null && !indvUpdItm.getEditOnly())
				// {

				// }

				Audit auditData = dtls.getAuditData();
				auditData.setLastModifiedDateTime(LocalDateTime.now());
				dtls.setAuditData(dtls.getAuditData());

				itemDetailsRepository.save(dtls);
			}

		}

		CycleState cycleState = cycleStateRepository.findByStateName("Under Review");

		for (Integer indvCycleId : cycleIds) {
			final CertificationItemDetails certificationItemDetails = new CertificationItemDetails();
			certificationItemDetails.setCycleState(cycleState);

			certificationCycle = cycleRepository.findById(indvCycleId).get();
			certificationCycle.setCertificationCycleId(indvCycleId);
			certificationItemDetails.setCertificationCycle(certificationCycle);

			List<CertificationItemDetails> itemDetails = itemDetailsRepository
					.findByCertificationCycleCertificationCycleIdAndCycleStateCycleStateId(indvCycleId,
							cycleState.getCycleStateId());
			// final Example<CertificationItemDetails> queryParameters =
			// Example.of(certificationItemDetails);
			// final List<CertificationItemDetails> itemDetails =
			// itemDetailsRepository.findAll(queryParameters);

			if (CollectionUtils.isEmpty(itemDetails) ) {
				cycleState = cycleStateRepository.findByStateName("Pending Attestation");
				certificationCycle.setCycleState(cycleState);

				cycleRepository.save(certificationCycle);

				final AccessControlHierarchy hierarchy = acCycleService.getHierarchyDataById(
						certificationCycle.getAccessControlHierarchy().getAccessControlHierarchyId());
				Map<String, String> inMap = new HashMap<>();
				inMap.put("$cycleName$", certificationCycle.getName());

				inMap.put("$applicationName$", hierarchy.getDescriptionText());

				inMap.put("$dueDate$", certificationCycle.getDueDate().toString());

				String emailToBeSent = dtls.getCertificationCycle().getAccessControlHierarchy().getAcHierarchyPOCBag()
						.get(0).getAccountManager().getEmailAddressText();

				// emailService.sendEmail(emailToBeSent,inMap,"ACCOUNTMGRCOMP");

			}
			else if (undoFlag && !CollectionUtils.isEmpty(itemDetails))
			{
				cycleState = cycleStateRepository.findByStateName("With Account Manager");
				certificationCycle.setCycleState(cycleState);
				
				certificationItemDetails.setAuditData(
						auditInformation.setCreatorAuditData(10001));
				certificationItemDetails.setLifeCycleData(auditInformation.setCreateLifeCycle());
				certificationCycle.setLifeCycleData(null);
				cycleRepository.save(certificationCycle);
			}
			
		}

		return outString;
	}

}
