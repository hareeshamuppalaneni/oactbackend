package gov.dol.osha.oact.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the CYCLE_STATE information
 *
 * @author Skietech Development Team
 */
@Table(name = "OACT_CYCLE_STATE")
@Entity
@Data
@RequiredArgsConstructor
public class CycleState {

	@Id
	@GeneratedValue
	@Column(name = "CYCLE_STATE_ID")
	private Integer cycleStateId;

	@NotBlank(message = "State name is mandatory")
	@Size(min = 1, max = 100)
	@Column(name = "STATE_NM", length = 100)
	private String stateName;

	@NotBlank(message = "Sub state name is mandatory")
	@Size(min = 1, max = 100)
	@Column(name = "SUB_STATE_NM", length = 50)
	private String subStateName;

	@Size(min = 0, max = 1000)
	@Column(name = "DESCRIPTION_TX", length = 1000)
	private String descriptionText;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
