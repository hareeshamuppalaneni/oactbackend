package gov.dol.osha.oact.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import gov.dol.osha.oact.entities.OSHAUserRole;

/**
 * Repository interface for {@link OSHAUserRole} instances. Provides basic CRUD
 * operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface OSHAUserRoleRepository extends JpaRepository<OSHAUserRole, Integer> {

}
