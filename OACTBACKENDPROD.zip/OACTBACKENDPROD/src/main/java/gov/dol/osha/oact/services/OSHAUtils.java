package gov.dol.osha.oact.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Map;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;

@Component
public class OSHAUtils {

	@Autowired
	Environment env;

	String createAttestioPDF(Map<String, String> dataVals, String cycleName, String appName, String sufix) {

		String attestFileName = env.getProperty("ATTEST_TEMPLATE");

		String attestFileNameDest = env.getProperty("ATTEST_FILE_LOC") + cycleName + "_" + appName + sufix + ".docx";

		try {

			// FileUtils.copyFile(new File(attestFileName), new File(attestFileNameDest));
			XWPFDocument doc = new XWPFDocument(OPCPackage.open(attestFileName));

			for (XWPFParagraph p : doc.getParagraphs()) {
				for (XWPFRun r : p.getRuns()) {
					String text = r.getText(0);
					if (text != null && text.contains("$SYSTEM$")) {
						text = text.replace("$SYSTEM$", dataVals.get("$SYSTEM$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$APPLICATION$")) {
						text = text.replace("$APPLICATION$", dataVals.get("$APPLICATION$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$CONTACT$")) {
						text = text.replace("$CONTACT$", dataVals.get("$CONTACT$"));
						r.setText(text, 0);
					}

					if (text != null && text.contains("$SYSTEMOWNR$")) {
						text = text.replace("$SYSTEMOWNR$",
								dataVals.get("$SYSTEMOWNR$") == null ? "        " : dataVals.get("$SYSTEMOWNR$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$DATE$")) {
						text = text.replace("$DATE$", dataVals.get("$DATE$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$ACCOUNTMGR$")) {
						text = text.replace("$ACCOUNTMGR$", dataVals.get("$ACCOUNTMGR$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$SYSTEMOWNRTS$")) {
						text = text.replace("$SYSTEMOWNRTS$",
								dataVals.get("$SYSTEMOWNRTS$") == null ? "" : dataVals.get("$SYSTEMOWNRTS$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$ACCOUNTMGRTS$")) {
						text = text.replace("$ACCOUNTMGRTS$", dataVals.get("$ACCOUNTMGRTS$"));
						r.setText(text, 0);
					}
					if (text != null && text.contains("$SYSEMAIL$")) {
						text = text.replace("$SYSEMAIL$",
								dataVals.get("$SYSEMAIL$") == null ? "           " : dataVals.get("$SYSEMAIL$"));
						r.setText(text, 0);
					}

					if (text != null && text.contains("$ACCEMAIL$")) {
						text = text.replace("$ACCEMAIL$", dataVals.get("$ACCEMAIL$"));
						r.setText(text, 0);
					}

				}

			}

			doc.write(new FileOutputStream(attestFileNameDest));
			FileInputStream in = new FileInputStream(attestFileNameDest);
			XWPFDocument document = new XWPFDocument(in);
			File outFile = new File(attestFileNameDest + ".pdf");
			OutputStream out = new FileOutputStream(outFile);
			PdfOptions options = null;
			PdfConverter.getInstance().convert(document, out, options);
			out.flush();
			out.close();
			// doc.close();
			document.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return cycleName + "_" + appName + sufix + ".docx.pdf";

	}

}
