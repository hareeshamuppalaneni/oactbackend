package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used to provide Access Control Hierarchy data.
 *
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class AccessControlHierarchyPOCData {

	private Integer accessControlHierarchyPocId;

	@NotNull(message = "System owner is mandatory")
	private OSHAUserSummaryData systemOwner;

	private OSHAUserSummaryData systemPoc;

	@NotNull(message = "Certification coordinator is mandatory")
	private OSHAUserSummaryData certCoOrdinator;

	@NotNull(message = "Account manger is mandatory")
	private OSHAUserSummaryData accountManager;

	@Size(min = 0, max = 1000)
	private String accountManagerOfc;

	private OSHAUserSummaryData subaccountManager;

	@NotNull(message = "Parent access control hierarchy id is mandatory")
	private Integer parentAccessControlHierarchyId;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;

}
