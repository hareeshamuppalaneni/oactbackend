package gov.dol.osha.oact.entities;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This support class has fields required to set the audit information.
 * Information like who created the record,when it was created , who last
 * updated the record, when it was last updated and the optimistic locking
 * information.
 *
 * @author Skietech Development Team
 */
@Builder(toBuilder = true)
@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Audit implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "CREATE_TS")
	private LocalDateTime createDateTime;

	@Column(name = "CREATE_USER_ID")
	private Integer createUserId;

	@Column(name = "LAST_MOD_TS")
	private LocalDateTime lastModifiedDateTime;

	@NotNull(message = "LastModified user information is mandatory")
	@Column(name = "LAST_MOD_USER_ID")
	private Integer lastModifiedUserId;

	@Column(name = "LOCK_CONTROL_NO")
	private int lockControlNumber;

}
