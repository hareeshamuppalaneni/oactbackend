package gov.dol.osha.oact.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.StandardUserRoleData;
import gov.dol.osha.oact.entities.StandardUserRole;
import gov.dol.osha.oact.repositories.StandardUserRoleRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * This service class is used to implement the CRUD operation for standard user
 * roles information
 *
 * @author Skietech Development Team
 *
 */
@Validated
@Service
public class StandardUserRoleService {

	@Autowired
	private StandardUserRoleRepository userRoleRepository;

	@Autowired
	private AuditInformation auditInformation;

	public List<StandardUserRoleData> getUserRoles() {

		final List<StandardUserRole> standardUserRoles = userRoleRepository.findAll();
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(standardUserRoles, "standard user roles");
		final List<StandardUserRoleData> standardUserRolesData = new ArrayList<>();

		standardUserRoles.stream().forEach(stndUserRole -> {

			StandardUserRoleData standardUserRoleData = new StandardUserRoleData();
			BeanUtils.copyProperties(stndUserRole, standardUserRoleData);
			standardUserRoleData.setAuditData(auditInformation.getAuditData(stndUserRole.getAuditData()));
			standardUserRolesData.add(standardUserRoleData);
		});

		return standardUserRolesData;
	}

	public StandardUserRoleData createStandardUserRoles(@NotNull StandardUserRoleData standardUserRoleReq) {

		final StandardUserRole standardUserRole = new StandardUserRole();
		BeanUtils.copyProperties(standardUserRoleReq, standardUserRole);
		standardUserRole.setAuditData(
				auditInformation.setCreatorAuditData(standardUserRoleReq.getAuditData().getLastModifiedUserId()));
		standardUserRole.setLifeCycleData(auditInformation.setCreateLifeCycle());
		userRoleRepository.save(standardUserRole);
		return standardUserRoleReq;
	}

	public StandardUserRoleData updateStandardUserRoles(@NotNull StandardUserRoleData standardUserRoleReq) {

		OSHACommonValidations.updateServiceInputValidation(standardUserRoleReq.getStndUserRoleId(),
				standardUserRoleReq.getAuditData().getLockControlNumber());

		final StandardUserRole standardUserRole = getStandardUserRoleById(standardUserRoleReq.getStndUserRoleId());
		OSHACommonValidations.safeLockControlNumber(standardUserRoleReq.getAuditData().getLockControlNumber(),
				standardUserRole.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(standardUserRoleReq, standardUserRole);
		standardUserRole.setAuditData(auditInformation.setUpdateAuditData(standardUserRoleReq.getAuditData(),
				standardUserRole.getAuditData()));

		userRoleRepository.save(standardUserRole);
		return standardUserRoleReq;
	}

	public void deleteStandardUserRole(@NotNull Integer stndUserId) {

		userRoleRepository.delete(getStandardUserRoleById(stndUserId));
	}

	private StandardUserRole getStandardUserRoleById(Integer stndUserId) {

		final Optional<StandardUserRole> standardUserRole = userRoleRepository.findById(stndUserId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				standardUserRole.isEmpty() ? null : standardUserRole.get(), "standard user role");

		return standardUserRole.get();

	}
}
