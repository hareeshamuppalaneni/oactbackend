package gov.osha.domain.searchQuery;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used for Cycle State Search
 * 
 */
@Data
@RequiredArgsConstructor
public class CertificationCycleSearchQuery {

	private String identifier ;
	private String applicationName;
	private String regionName;
	private String officeName;

}
