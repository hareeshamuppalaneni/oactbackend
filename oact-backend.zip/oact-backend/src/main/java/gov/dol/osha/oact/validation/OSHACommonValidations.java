package gov.dol.osha.oact.validation;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.CONFLICT;
import static org.springframework.http.HttpStatus.NOT_FOUND;

import java.util.Collection;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import gov.dol.osha.oact.exceptionHandling.ErrorMessage;
import gov.dol.osha.oact.exceptionHandling.OSHAException;

/**
 * This class is used to do services common validations.
 *
 * @author Skietech Development Team
 */
public class OSHACommonValidations {

	/**
	 * Method is used to check if a particular data collection empty or not
	 *
	 * @param data         - input list
	 * @param errorMessage - error message
	 */

	public static <T> Collection<T> checkSearchCriteriaHaveDataInTheDB(final Collection<T> data,
			final String errorMessage) {

		if (CollectionUtils.isEmpty(data)) {
			throw new OSHAException(NOT_FOUND,
					new ErrorMessage("No data found for requested " + errorMessage + " search criteria"));
		}

		return data;
	}

	/**
	 * Method is used to check if a particular reference data exists or not
	 *
	 * @param data    - input object
	 * @param message - error message
	 * @return- Throws 404 if record not found
	 */
	public static <T> T checkSearchCriteriaHaveDataInTheDBObject(final T data, final String message) {

		if (data == null) {
			throw new OSHAException(NOT_FOUND, new ErrorMessage(message + " id doesn't exist in the database"));
		}
		return data;
	}

	/**
	 * Method is used to validate Lock Control Number.if the requested lock control
	 * number doesn't match with existing lock control number in the data base then
	 * it will throw 409 error.
	 *
	 * @param inputLockControlNumber    - input lock control number cannot be null.
	 * @param existingLockControlNumber - existing lock control number in the data
	 *                                  base
	 * @return- Throws 409 if record not found
	 */
	public static void safeLockControlNumber(final int inputLockControlNumber, final int existingLockControlNumber) {

		if (inputLockControlNumber != existingLockControlNumber) {
			throw new OSHAException(CONFLICT, new ErrorMessage(
					"Someone Has Updated The Record.Please Refersh The Page And Get The Latest Data."));
		}
	}

	/**
	 * Method is used to check if the record already exist or not.
	 *
	 * @param data    - input object
	 * @param message - error message
	 * @return- Throws 400 if record not found
	 */
	public static <T> T recordAlreadyExistInDB(final T data, final String message) {

		if (data != null) {
			throw new OSHAException(BAD_REQUEST, new ErrorMessage(message));
		}
		return data;
	}

	/**
	 * Method is used to check input object data is null or not. if the value is
	 * then throws exception.
	 *
	 * @param data    - input object
	 * @param message - error message
	 * @return- Throws 400 if record not found
	 */
	public static <T> T safeObject(final T data, final String message) {

		if (data == null) {
			throw new OSHAException(BAD_REQUEST, new ErrorMessage(message));
		}
		return data;
	}

	/**
	 * Method is used to check requested input string is empty or null.if the value
	 * is empty then it throws 400 error.
	 *
	 * @param value   - input object
	 * @param message - error message
	 * @return- Throws 400 if record not found
	 */
	public static void validateString(final String value, final String message) {

		if (StringUtils.isEmpty(value)) {
			throw new OSHAException(BAD_REQUEST, new ErrorMessage(message));
		}
	}

	/**
	 * Method is used to check requested input string is empty or null.if the value
	 * is empty then it throws 400 error.
	 *
	 * @param value   - input object
	 * @param message - error message
	 * @return- Throws 400 if record not found
	 */
	public static void validateCollection(final Collection<?> value, final String message) {

		if (CollectionUtils.isEmpty(value)) {
			throw new OSHAException(BAD_REQUEST, new ErrorMessage(message));
		}
	}

	/**
	 * Method is used to check requested input string is empty or null.if the value
	 * is empty then it throws 400 error.
	 *
	 * @param value   - input object
	 * @param message - error message
	 * @return- Throws 400 if record not found
	 */
	public static void updateServiceInputValidation(final Integer primarKeyId, final Integer lockControlNumber) {

		safeObject(primarKeyId, "Primary element id is mandatory");

		if (lockControlNumber == 0) {
			throw new OSHAException(BAD_REQUEST, new ErrorMessage("Lockcontrol number is mandatory"));
		}

	}

	private OSHACommonValidations() {
	}
}
