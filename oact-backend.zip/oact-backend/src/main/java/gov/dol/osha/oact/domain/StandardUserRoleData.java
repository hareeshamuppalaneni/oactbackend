package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide Standard user role data.
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class StandardUserRoleData {

	private Integer stndUserRoleId;

	@NotBlank(message = "User role name is mandatory")
	@Size(min = 1, max = 200)
	private String userRoleName;

	@NotBlank(message = "User role description is mandatory")
	@Size(min = 1, max = 200)
	private String descriptionText;

	@Size(min = 0, max = 200)
	private String dispalyName;

	private String primaryIndicator;
	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;
}
