package gov.dol.osha.oact.utils;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

//@PropertySource("classpath:notification.properties")
@Slf4j
@Component
public class EmailNotificationService {

	@Value("${notification.email.body.message.cycle.initiate}")
	private String emailBody;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	Environment env;

	public void sendEmail(String fromEmail, String toEmail, String subject, String body, String application,
			String firstName) {

		try {
			final SimpleMailMessage mailMessage = new SimpleMailMessage();
			mailMessage.setFrom(fromEmail);
			mailMessage.setTo(toEmail);
			mailMessage.setSubject(subject);
			mailMessage.setText(String.format(emailBody, firstName, application));
			mailSender.send(mailMessage);
		} catch (Exception ex) {

			log.error(ex.getLocalizedMessage());
		}
	}

	public void sendEmail(String toEmail, Map<String, String> messageTextVals, String eventType) {

		try {
			String configuredEvents = env.getProperty("notification.event");
			log.info("original Email : " + toEmail);
			if (StringUtils.isNotBlank(configuredEvents) && configuredEvents.contains(eventType)) {
				final MimeMessage mailMessage = mailSender.createMimeMessage();
				mailMessage.setContent(toEmail, eventType);

				MimeMessageHelper helper = new MimeMessageHelper(mailMessage, true);
				helper.setFrom(env.getProperty(eventType + ".FROM"));
				String emailTo = toEmail;
				log.info("Email sShould go to :" + emailTo);
				if (StringUtils.equalsAnyIgnoreCase(env.getProperty(eventType + ".TO.OVERRIDE"), "Y")) {
					emailTo = env.getProperty(eventType + ".TO");
				}
				log.info("Email Went to  due to override file:" + emailTo);
				log.info("Targeted Email : " + emailTo);
				helper.setTo(InternetAddress.parse(emailTo));

				String subject = env.getProperty(eventType + ".SUBJECT");

				String emailBody = env.getProperty(eventType + ".BODY");

				if (messageTextVals != null && messageTextVals.size() > 0) {
					for (Map.Entry<String, String> entry : messageTextVals.entrySet()) {

						String keyToLookUp = entry.getKey();
						String keyToreplace = entry.getValue();
						emailBody = emailBody.replace(keyToLookUp, keyToreplace);
						subject = subject.replace(keyToLookUp, keyToreplace);
					}
				}
				helper.setSubject(subject);
				helper.setText(emailBody, true);

				mailSender.send(mailMessage);
			}

		} catch (Exception ex) {

			log.error(ex.getLocalizedMessage());
		}
	}

	public void sendEmailWithAttachment(String toEmail, Map<String, String> messageTextVals, String eventType,
			List<File> attachements) {

		try {
			String configuredEvents = env.getProperty("notification.event");
			log.info("original Email : " + toEmail);
			if (StringUtils.isNotBlank(configuredEvents) && configuredEvents.contains(eventType)) {
				final MimeMessage mailMessage = mailSender.createMimeMessage();
				mailMessage.setContent(toEmail, eventType);

				MimeMessageHelper helper = new MimeMessageHelper(mailMessage, true);
				helper.setFrom(env.getProperty(eventType + ".FROM"));
				String emailTo = toEmail;
				log.info("Email sShould go to :" + emailTo);
				if (StringUtils.equalsAnyIgnoreCase(env.getProperty(eventType + ".TO.OVERRIDE"), "Y")) {
					emailTo = env.getProperty(eventType + ".TO");
				}
				log.info("Email Went to  due to override file:" + emailTo);
				log.info("Targeted Email : " + emailTo);
				helper.setTo(InternetAddress.parse(emailTo));

				String subject = env.getProperty(eventType + ".SUBJECT");

				String emailBody = env.getProperty(eventType + ".BODY");

				if (messageTextVals != null && messageTextVals.size() > 0) {
					for (Map.Entry<String, String> entry : messageTextVals.entrySet()) {
						emailBody = emailBody.replace(entry.getKey(), entry.getValue());
						subject = subject.replace(entry.getKey(), entry.getValue());
					}
				}
				helper.setSubject(subject);
				helper.setText(emailBody, true);

				if (CollectionUtils.isNotEmpty(attachements)) {

					for (File indvFile : attachements) {
						helper.addAttachment(indvFile.getName(), indvFile);
					}

				}

				mailSender.send(mailMessage);
			}

		} catch (Exception ex) {

			log.error(ex.getLocalizedMessage(),ex);
		}
	}

}
