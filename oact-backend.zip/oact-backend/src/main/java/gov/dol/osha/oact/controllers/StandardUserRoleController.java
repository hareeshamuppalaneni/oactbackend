package gov.dol.osha.oact.controllers;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.StandardUserRoleData;
import gov.dol.osha.oact.services.StandardUserRoleService;

/**
 * Controller to standard user roles data
 *
 * @author Skietech Development Team
 */
@RestController
@RequestMapping("/standard-user-roles")
public class StandardUserRoleController {

	@Autowired
	private StandardUserRoleService userRoleService;

	@GetMapping
	public List<StandardUserRoleData> getStandardUserRoles() {

		return userRoleService.getUserRoles();
	}

	@PostMapping
	public StandardUserRoleData createStandardUserRole(
			@Valid @RequestBody final StandardUserRoleData standardUserRole) {

		return userRoleService.createStandardUserRoles(standardUserRole);
	}

	@PutMapping
	public StandardUserRoleData updateStandardUserRole(
			@Valid @RequestBody final StandardUserRoleData standardUserRole) {

		return userRoleService.updateStandardUserRoles(standardUserRole);
	}

	@DeleteMapping(value = "/{userRoleIdentifier}")
	public void deleteStandardUserRole(@NotNull @PathVariable("userRoleIdentifier") final Integer userRoleIdentifier) {

		userRoleService.deleteStandardUserRole(userRoleIdentifier);
	}

}
