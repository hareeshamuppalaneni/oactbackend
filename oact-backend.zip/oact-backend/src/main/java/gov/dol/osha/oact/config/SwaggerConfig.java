
package gov.dol.osha.oact.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This class is used to configure Swagger configurations. The Swagger 2 is
 * enabled through the @EnableSwagger2 annotation.This configuration is enough
 * to integrate Swagger 2 into rest services.
 *
 * @author Skietech Development Team
 */
@EnableSwagger2
@Configuration
public class SwaggerConfig {

	@Bean
	public Docket docket() {
		return new Docket(DocumentationType.SWAGGER_2).enable(true)
				.apiInfo(new ApiInfoBuilder().title("OSHA Certification API's")
						.description("OSHA Certification Services").version("1.0").build())
				.select().apis(RequestHandlerSelectors.basePackage("gov.dol.osha.oact.controllers"))
				.paths(PathSelectors.any()).build();
	}
}
