package gov.dol.osha.oact.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.CertificationItemDetailsData;
import gov.dol.osha.oact.domain.CertificationItemEdits;
import gov.dol.osha.oact.domain.UndoItemDetails;
import gov.dol.osha.oact.domain.searchQuery.CertificationItemDetailsSearchQuery;
import gov.dol.osha.oact.services.CertificationItemDetailsService;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * Controller to handle certification cycles
 *
 * @author Skietech Development Team
 */
@RestController
@RequestMapping("/certification-item-details")
public class CertificationItemDetailsController {

	@Autowired
	private CertificationItemDetailsService itemDetailsService;

	@GetMapping
	public List<CertificationItemDetailsData> getCertificationItemDetails(
			final CertificationItemDetailsSearchQuery searchQuery) {

		if (StringUtils.isNotBlank(searchQuery.getLoginEmail())) {
			return itemDetailsService.getCertificationItemDetailsByEmail(searchQuery.getLoginEmail().trim());
		} else {
			return itemDetailsService.getCertificationItemDetails(searchQuery, null, null, false);
		}

	}

	@PostMapping
	public CertificationItemDetailsData createCertificationItemDetails(
			@Valid @RequestBody final CertificationItemDetailsData itemDetailsDataReq) {

		return itemDetailsService.createCertificationItemDetails(itemDetailsDataReq);
	}

	@PutMapping
	public CertificationItemDetailsData updateCertificationItemDetails(
			@Valid @RequestBody final CertificationItemDetailsData itemDetailsDataReq) {

		return itemDetailsService.updateCertificationItemDetails(itemDetailsDataReq);
	}

	@PutMapping(value = "/edit-items")
	public String editCertificationItems(@Valid @RequestBody final List<CertificationItemEdits> itemDetailsDataReq) {

		return itemDetailsService.editCertificationItemDetails(itemDetailsDataReq,false);
	}
	
	@PutMapping(value = "/undo-items")
	public String undoCertificationItems(@Valid @RequestBody @NotNull final UndoItemDetails itemList) {
		
		
		List<CertificationItemEdits> itemDetailsDataReq = new ArrayList<CertificationItemEdits>();
		for (Integer indvItem : itemList.getItemsList())
		{
			CertificationItemEdits indvCertItems = new CertificationItemEdits();
			indvCertItems.setCycleItemId(indvItem);
			itemDetailsDataReq.add(indvCertItems);
		}
		OSHACommonValidations.validateCollection(itemDetailsDataReq, "Mandatory input Review items are missing");
		return itemDetailsService.editCertificationItemDetails(itemDetailsDataReq,true);
	}

	@DeleteMapping(value = "/{itemDetailsId}")
	public void deleteCertificationItemDetails(@NotNull @PathVariable("itemDetailsId") final Integer itemDetailsId) {

		itemDetailsService.deleteCertificationItemDetails(itemDetailsId);
	}

}
