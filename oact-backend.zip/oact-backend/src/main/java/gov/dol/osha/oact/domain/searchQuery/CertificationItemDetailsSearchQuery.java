package gov.dol.osha.oact.domain.searchQuery;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used for Certification Item Details Search
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
public class CertificationItemDetailsSearchQuery {

	private Integer itemId;
	private Integer cycleId;
	private String loginEmail;
	private String itemOffice;
}
