package gov.dol.osha.oact.domain.searchQuery;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide specific user data
 *
 * @author Skietech Development Team
 */
@JsonInclude(NON_NULL)
@Data
public class OSHAUserSearchQuery {

	private Integer oshaUserId;
	private String employeeNumber;
	private String firstName;
	private String lastName;
	private String loginIdentifier;
	private String email;
}
