package gov.dol.osha.oact.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import gov.dol.osha.oact.entities.OSHAUser;

/**
 * Repository interface for {@link OSHAUser} instances. Provides basic CRUD
 * operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface OSHAUserRepository extends JpaRepository<OSHAUser, Integer>, QueryByExampleExecutor<OSHAUser> {

	OSHAUser findByLoginId(String loginId);

	OSHAUser findByEmailAddressTextIgnoreCase(String emailAddressText);
}
