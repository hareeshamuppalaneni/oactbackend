package gov.dol.osha.oact.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import gov.dol.osha.oact.entities.StandardCycle;

/**
 * Repository interface for {@link StandardCycle} instances. Provides basic CRUD
 * operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface StandardCycleRepository extends JpaRepository<StandardCycle, Integer> {

	@Query("select sc from StandardCycle sc where CURRENT_DATE  between lifeCycleData.beginEffectiveDate and lifeCycleData.endEffectiveDate")
	StandardCycle getCurrentStandardCyle();
}
