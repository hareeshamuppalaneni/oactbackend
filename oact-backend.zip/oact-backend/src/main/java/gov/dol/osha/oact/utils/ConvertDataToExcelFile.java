package gov.dol.osha.oact.utils;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import gov.dol.osha.oact.domain.CertificationItemDetailsData;
import gov.dol.osha.oact.domain.searchQuery.CertificationItemDetailsSearchQuery;
import gov.dol.osha.oact.entities.CertificationCycle;
import gov.dol.osha.oact.exceptionHandling.ErrorMessage;
import gov.dol.osha.oact.exceptionHandling.OSHAException;
import gov.dol.osha.oact.repositories.CertifactionCycleRepository;
import gov.dol.osha.oact.services.CertificationItemDetailsService;
import gov.dol.osha.oact.validation.OSHACommonValidations;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ConvertDataToExcelFile {

	@Autowired
	private CertificationItemDetailsService itemService;
	
	@Autowired
	private CertifactionCycleRepository acCycleRepository;

	@Autowired
	private Environment env;

	public ResponseEntity<InputStreamResource> writeDataToExcel(Integer cycleId) throws IOException {

		final CertificationItemDetailsSearchQuery searchQuery = new CertificationItemDetailsSearchQuery();
		searchQuery.setCycleId(cycleId);

		final List<CertificationItemDetailsData> itemDetailsBag = itemService.getCertificationItemDetails(searchQuery,
				null, null, false);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(itemDetailsBag, "item details");
		
		CertificationCycle cycleData = acCycleRepository.findById(cycleId).get();
		String reviewerName =cycleData.getAccessControlHierarchy().getAcHierarchyPOCBag().get(0).getAccountManager().getFullName();
		if(!cycleData.getCycleState().getStateName().equals("With System Owner"))
		{
			reviewerName =cycleData.getAccessControlHierarchy().getAcHierarchyPOCBag().get(0).getAccountManager().getFullName();
		}
		Date reviewDate = new Date();
		SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
		String stringDate = DateFor.format(reviewDate);

		final List<String[]> rowHeaders = new ArrayList<>();
		String headerComments = "Instructions: Please enter the information below for each account assigned to users, for general and privileged users. If a user has more "
				+ " than one account, please insert a separate row for each account. Use the Comments column to provide details to explain Review Results"
				+ " selection and/or explain any other results from the review. Ensure you review for consistency with access control policies, e.g. period "
				+ "of inactivity resulting in account being disabled: compare Last Login Date and Account status entries.";

		String[] headerLineOne = { "Agency", "OSHA ", " ", headerComments };
		String[] headerLineTwo = { "Review Date" ,stringDate};
		String[] headerLineThree = { "Reviewer Name", reviewerName};
		String[] headerLineFour = { " " };
		String[] headerLineFive = { "Last Name", "First Name", "Middle Initial", "Agency", "Sub-Agency",
				"User Email Address", "UserID", "System Name", "User Type", "Account Type", "Account Creation Date",
				"Last Login Date", "Account Status", "Review Results", "Comments" };

		rowHeaders.add(headerLineOne);
		rowHeaders.add(headerLineTwo);
		rowHeaders.add(headerLineThree);
		rowHeaders.add(headerLineFour);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("CycleData");

		/*
		 * XSSFFont font = ((XSSFWorkbook) workbook).createFont();
		 * font.setFontName("Arial"); font.setFontHeightInPoints((short) 12);
		 * font.setColor(IndexedColors.WHITE.index); font.setBold(true);
		 *
		 * CellStyle headerCellStyle = workbook.createCellStyle();
		 * headerCellStyle.setFillForegroundColor(IndexedColors.DARK_BLUE.index);
		 * headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		 * headerCellStyle.setWrapText(true); headerCellStyle.setFont(font);
		 */

		int headerCount = 0;
		for (String[] indHeader : rowHeaders) {

			Row headerRow = sheet.createRow(headerCount);
			if (headerCount == 3) {
				break;
			}
			for (int i = 0; i < indHeader.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(indHeader[i]);
				// cell.setCellStyle(headerCellStyle);
			}
			headerCount = headerCount + 1;
		}

		XSSFFont dataHeaderFont = workbook.createFont();
		dataHeaderFont.setFontName("Arial");
		dataHeaderFont.setFontHeightInPoints((short) 12);
		dataHeaderFont.setColor(IndexedColors.WHITE1.index);
		dataHeaderFont.setBold(true);

		CellStyle dataHeaderCellStyle = workbook.createCellStyle();
		dataHeaderCellStyle.setFillForegroundColor(IndexedColors.ROYAL_BLUE.index);
		dataHeaderCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		dataHeaderCellStyle.setWrapText(true);
		dataHeaderCellStyle.setFont(dataHeaderFont);

		Row headerRowFive = sheet.createRow(4);

		for (int i = 0; i < headerLineFive.length; i++) {
			Cell cell = headerRowFive.createCell(i);
			cell.setCellValue(headerLineFive[i]);
			cell.setCellStyle(dataHeaderCellStyle);
		}

		sheet.addMergedRegion(new CellRangeAddress(0, 2, 3, 14));
		sheet.setAutoFilter(new CellRangeAddress(4, 4, 0, 14));

		int rowNum = 5;

		String cycleName = "";
		String excelFileNameDest = env.getProperty("ATTEST_FILE_LOC");

		for (CertificationItemDetailsData itemDetails : itemDetailsBag) {
			cycleName = itemDetails.getName().substring(0, itemDetails.getName().lastIndexOf("_"));
			Map<String, String> itemsMap = itemDetails.getCycleItemDetails();
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "lastName"), " "));
			row.createCell(1).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "firstName"), " "));
			row.createCell(2)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "middleInitial"), " "));
			row.createCell(3).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "agency"), " "));
			row.createCell(4).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "subAgency"), " "));
			row.createCell(5)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "userEmailAddress"), " "));
			row.createCell(6).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "userId"), " "));
			row.createCell(7).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "systemName"), " "));
			row.createCell(8).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "userType"), " "));
			row.createCell(9).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "accountType"), " "));
			row.createCell(10)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "accountCreationDate"), " "));
			row.createCell(11)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "lastLoginDate"), " "));
			row.createCell(12)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "accountStatus"), " "));
			row.createCell(13)
					.setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "reviewResults"), " "));
			row.createCell(14).setCellValue(StringUtils.defaultString(MapUtils.getString(itemsMap, "comments"), " "));
		}

		for (int i = 0; i < headerLineFive.length; i++) {
			sheet.autoSizeColumn(i);
		}

		try {
			// Write the workbook in file system
			excelFileNameDest = excelFileNameDest + cycleName + ".xlsx";
			FileOutputStream out = new FileOutputStream(new File(excelFileNameDest));
			workbook.write(out);
			out.close();
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		} finally {
			workbook.close();
		}
		return downloadFileFromMount(new File(excelFileNameDest));
	}

	private ResponseEntity<InputStreamResource> downloadFileFromMount(final File file) {

		try {

			if (file.exists()) {

				final byte[] fileContent = Files.readAllBytes(file.toPath());

				final InputStreamResource inputStreamResource = new InputStreamResource(
						new ByteArrayInputStream(fileContent));

				return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(inputStreamResource);

			} else {

				throw new OSHAException(BAD_REQUEST,

						new ErrorMessage("File is not available in store location"));

			}

		} catch (final IOException ex) {

			log.error(ex.getMessage(), ex);

			throw new OSHAException(BAD_REQUEST,
					new ErrorMessage("Exception occurred while loading the document from mount"));

		}

	}

}
