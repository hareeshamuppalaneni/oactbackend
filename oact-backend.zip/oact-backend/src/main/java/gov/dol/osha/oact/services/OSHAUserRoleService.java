package gov.dol.osha.oact.services;

import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.OSHAUserRoleData;
import gov.dol.osha.oact.domain.OSHAUserRoleResponse;
import gov.dol.osha.oact.domain.StandardUserRoleData;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserRoleQuery;
import gov.dol.osha.oact.entities.OSHAUserRole;
import gov.dol.osha.oact.repositories.OSHAUserRoleRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

/**
 * This service class is used to implement the CRUD operation for OSHA user role
 * information
 *
 * @author Skietech Development Team
 *
 */
@Validated
@Service
public class OSHAUserRoleService {

	@Autowired
	private OSHAUserRoleRepository oshaUserRoleRepository;

	@Autowired
	private OSHAUserService oshaUserService;

	@Autowired
	private StandardUserRoleService stndRoleSrvc;

	@Autowired
	private AuditInformation auditInformation;

	public OSHAUserRoleResponse getOSHAUserRoleData(@NotNull final OSHAUserRoleQuery searchQuery) {

		final OSHAUserRole oshaUserRole = new OSHAUserRole();
		oshaUserRole.setOshaUserId(searchQuery.getUserId());

		final Example<OSHAUserRole> queryParameters = Example.of(oshaUserRole);
		final List<OSHAUserRole> oshaUserRoleBag = oshaUserRoleRepository.findAll(queryParameters);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(oshaUserRoleBag, "osha user role");

		OSHAUserRoleResponse userResponse = new OSHAUserRoleResponse();
		oshaUserService.getOSHAUserById(oshaUserRoleBag.get(0).getOshaUserId());

		List<StandardUserRoleData> listOfRoles = stndRoleSrvc.getUserRoles();

		oshaUserRoleBag.stream().forEach(indOshaUserRole -> {

			listOfRoles.stream().forEach(indStndRole -> {

				if (indStndRole.getStndUserRoleId().equals(indOshaUserRole.getUserRoleId())) {
					indStndRole.setPrimaryIndicator(indOshaUserRole.getPrimaryIndicator());
					userResponse.getRoleInformation().add(indStndRole);

				}
			});

			/*
			 * final OSHAUserRoleData oshaUserRoleData = new OSHAUserRoleData();
			 * BeanUtils.copyProperties(indOshaUserRole, oshaUserRoleData);
			 * oshaUserRoleData.setAuditData(auditInformation.getAuditData(indOshaUserRole.
			 * getAuditData())); oshaUserRoleDataBag.add(oshaUserRoleData);
			 */
		});

		return userResponse;
	}

	public OSHAUserRoleData createOSHAUserRoleData(@NotNull OSHAUserRoleData oshaUserRoleDataReq) {

		final OSHAUserRole oshaUserRole = new OSHAUserRole();
		BeanUtils.copyProperties(oshaUserRoleDataReq, oshaUserRole);
		oshaUserRole.setAuditData(
				auditInformation.setCreatorAuditData(oshaUserRoleDataReq.getAuditData().getLastModifiedUserId()));
		oshaUserRole.setLifeCycleData(auditInformation.setCreateLifeCycle());
		oshaUserRoleRepository.save(oshaUserRole);
		return oshaUserRoleDataReq;
	}

	public OSHAUserRoleData updateOSHAUserRoleData(@NotNull OSHAUserRoleData oshaUserRoleDataReq) {

		OSHACommonValidations.updateServiceInputValidation(oshaUserRoleDataReq.getOshaUserRoleId(),
				oshaUserRoleDataReq.getAuditData().getLockControlNumber());

		final OSHAUserRole oshaUserRole = getOSHAUserRoleById(oshaUserRoleDataReq.getOshaUserRoleId());
		OSHACommonValidations.safeLockControlNumber(oshaUserRoleDataReq.getAuditData().getLockControlNumber(),
				oshaUserRole.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(oshaUserRoleDataReq, oshaUserRole);
		oshaUserRole.setAuditData(
				auditInformation.setUpdateAuditData(oshaUserRoleDataReq.getAuditData(), oshaUserRole.getAuditData()));
		oshaUserRoleRepository.save(oshaUserRole);
		return oshaUserRoleDataReq;
	}

	public void deleteOSHAUserRoleData(@NotNull Integer oshaUserRoleId) {

		oshaUserRoleRepository.delete(getOSHAUserRoleById(oshaUserRoleId));
	}

	private OSHAUserRole getOSHAUserRoleById(Integer oshaUserRoleId) {

		final Optional<OSHAUserRole> oshaUserRoleOpt = oshaUserRoleRepository.findById(oshaUserRoleId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				oshaUserRoleOpt.isEmpty() ? null : oshaUserRoleOpt.get(), "osha user role");
		return oshaUserRoleOpt.get();
	}

}
