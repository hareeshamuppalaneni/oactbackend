package gov.dol.osha.oact.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.AuditData;
import gov.dol.osha.oact.entities.Audit;
import gov.dol.osha.oact.entities.LifeCycle;

/**
 * This class is used to set the Audit Information.
 *
 * @author Skietech Development Team
 */
@Validated
@Component
public class AuditInformation {

	/**
	 * Setting the audit information for create operations.
	 *
	 * @return - Audit information
	 */
	public Audit setCreatorAuditData(@NotNull Integer applLoginUserId) {

		final Audit audit = new Audit();
		audit.setCreateUserId(applLoginUserId);
		audit.setLastModifiedUserId(applLoginUserId);
		audit.setLastModifiedDateTime(LocalDateTime.now());
		audit.setCreateDateTime(LocalDateTime.now());
		audit.setLockControlNumber(1);
		return audit;
	}

	/**
	 * Setting the audit information for update operations.
	 *
	 * @return - Audit information
	 */
	public Audit setUpdateAuditData(@NotNull AuditData inputAudit, @NotNull Audit dbAudit) {

		dbAudit.setLastModifiedDateTime(LocalDateTime.now());
		dbAudit.setLastModifiedUserId(inputAudit.getLastModifiedUserId());
		dbAudit.setLockControlNumber(inputAudit.getLockControlNumber() + 1);
		return dbAudit;
	}

	/**
	 * Setting the Life Cycle information for create operations.
	 *
	 * @return - LifeCycle information
	 */
	public LifeCycle setCreateLifeCycle() {

		final LifeCycle lifeCycle = new LifeCycle();
		lifeCycle.setBeginEffectiveDate(
				lifeCycle.getBeginEffectiveDate() != null ? lifeCycle.getBeginEffectiveDate() : LocalDate.now());
		return lifeCycle;
	}

	public AuditData getAuditData(final Audit audit) {

		final AuditData auditData = new AuditData();
		auditData.setLastModifiedUserId(audit.getLastModifiedUserId());
		auditData.setLockControlNumber(audit.getLockControlNumber());
		return auditData;
	}

}
