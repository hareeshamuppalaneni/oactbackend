package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used to provide OSHA user data.
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
@JsonInclude(NON_NULL)
public class OSHAUserSummaryData {

	private Integer oshaUserId;

	private String employeeNumber;

	private String firstName;

	private String lastName;

	private String middleName;

	private String fullName;

	private String loginId;

	private String emailAddressText;

	private String office;

	private String rid;
}
