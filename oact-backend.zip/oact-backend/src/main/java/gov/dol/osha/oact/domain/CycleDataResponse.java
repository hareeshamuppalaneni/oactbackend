package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide Access control cycle data.
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class CycleDataResponse {

	private Integer certificationCycleId;

	private String name;
	
	private String excelFileName;

	private String descriptionText;

	private LocalDate dueDate;

	private LocalDate cycleStartDate;

	private LocalDate cycleEndDate;

	private Integer daysTillDueDate;

	private LocalDateTime iAttestedTS;

	private LocalDateTime fAttestedTS;

	private Integer iAttestedBy;

	private Integer fAttestedBy;

	private CycleStateData cycleSate;
	boolean uploadFlag = true;

	private List<CertificationItemDetailsData> itemDetails;

	private AccessControlHierarchyPOCFlowSummary pocData;

	private AuditData auditData;
}
