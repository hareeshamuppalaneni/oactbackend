package gov.dol.osha.oact.controllers;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.AccessControlCycleBulkData;
import gov.dol.osha.oact.domain.AccessControlCycleSummaryData;
import gov.dol.osha.oact.domain.CycleAttestationReq;
import gov.dol.osha.oact.domain.CycleCollectionData;
import gov.dol.osha.oact.domain.CycleDataResponse;
import gov.dol.osha.oact.domain.searchQuery.AccessControlCycleQuery;
import gov.dol.osha.oact.services.CertifcationCycleService;

/**
 * Controller to handle certification cycles
 *
 * @author Skietech Development Team
 */
@RestController
@RequestMapping("/certification-cycles")
public class CertificationCycleController {

	@Autowired
	private CertifcationCycleService certificationCycleService;

	@GetMapping
	public List<CycleDataResponse> getAccessControlCycleData(final AccessControlCycleQuery searchQuery) {

		return certificationCycleService.getAccessControlCycleData(searchQuery);
	}

	@GetMapping(value = "/attestation")
	public List<ConcurrentHashMap<String, Object>> getAttestationData(
			@RequestParam("email") @NotNull final String email) {

		AccessControlCycleQuery searchQuery = new AccessControlCycleQuery();
		searchQuery.setEmail(email);

		return certificationCycleService.getAttestationData(email);

	}

	/*
	 * @PostMapping public AccessControlCycleData createAccessControlCycleData(
	 *
	 * @Valid @RequestBody final AccessControlCycleData accessControlCycleDataReq) {
	 *
	 * return certificationCycleService.createAccessControlCycleData(
	 * accessControlCycleDataReq); }
	 */

	@PostMapping
	public CycleCollectionData createCycleAndItems(@Valid @RequestBody final CycleCollectionData cycDataReq) {

		return certificationCycleService.createAccessControlCycleData(cycDataReq);
	}

	@PutMapping
	public AccessControlCycleSummaryData updateAccessControlCycleData(
			@Valid @RequestBody final AccessControlCycleSummaryData accessControlCycleDataReq) {

		return certificationCycleService.updateAccessControlCycleData(accessControlCycleDataReq);
	}

	@PutMapping(value = "/bulk")
	public AccessControlCycleBulkData bulkUpdateAccessControlCycleData(
			@Valid @RequestBody final AccessControlCycleBulkData cycleBulkDataReq) {

		return certificationCycleService.bulkUpdateAccessControlCycleData(cycleBulkDataReq);
	}

	@DeleteMapping(value = "/{certificationCycleId}")
	public void deleteAccessControlCycleData(
			@NotNull @PathVariable("accessControlCycleId") final Integer accessControlCycleId) {

		certificationCycleService.deleteAccessControlCycleData(accessControlCycleId);
	}

	@PostMapping(value = "/attestation")
	public void attestationCycle(@RequestBody CycleAttestationReq cycleAttsReq) {

		certificationCycleService.attestation(cycleAttsReq.getEmailId(), cycleAttsReq.getCycleId());

	}

	@GetMapping(value = "/fetchAttestaionPDF", produces = MediaType.APPLICATION_PDF_VALUE)

	public ResponseEntity<InputStreamResource> fetchAttestaionPDF(
			@RequestParam("cycleId") @NotNull final Integer cycleId) {

		return certificationCycleService.fetchAttestationPDF(cycleId);
	}

}
