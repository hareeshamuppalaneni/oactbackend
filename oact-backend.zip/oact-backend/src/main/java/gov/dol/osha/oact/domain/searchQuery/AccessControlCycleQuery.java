package gov.dol.osha.oact.domain.searchQuery;

import lombok.Data;

/**
 * This class is used for Access Control Cycle Search
 *
 * @author Skietech Development Team
 */
@Data
public class AccessControlCycleQuery {

	private Integer accessControlCycleId;
	private String name;
	private String organizationType;
	private Integer accessControlHierarchyId;
	private Integer oshahUserId;
	private Integer oshaUserIdentifier;
	private String email;
	private String cycleState;
}
