package gov.dol.osha.oact.domain;

import java.time.LocalDate;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the CertificationItemDetailsData information
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
public class CertificationItemDetailsData {

	private Integer cycleItemId;

	@NotBlank(message = "Item name is mandatory")
	@Size(min = 1, max = 100)
	private String name;

	@Size(min = 0, max = 1000)
	private String descriptionText;

	@NotNull(message = "Cycle state id is mandatory")
	private CycleStateData cycleState;

	@NotNull(message = "Certification cycle id is mandatory")
	private Integer cycleId;

	@NotNull(message = "Due date is mandatory")
	private LocalDate dueDate;

	@NotNull(message = "Item details is mandatory")
	private Map<String, String> cycleItemDetails;

	@Size(min = 0, max = 320)
	private String office;

	@Size(min = 0, max = 320)
	private String rid;

	private AccessControlHierarchyPOCFlowSummary pocData;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;

}
