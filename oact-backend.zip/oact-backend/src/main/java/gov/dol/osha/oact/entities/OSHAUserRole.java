package gov.dol.osha.oact.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the OSHA_USER_ROLE information
 *
 * @author Skietech Development Team
 */
@Table(name = "OACT_USER_ROLE")
@Entity
@Data
@RequiredArgsConstructor
public class OSHAUserRole {

	@Id
	@GeneratedValue
	@Column(name = "OSHA_USER_ROLE_ID")
	private Integer oshaUserRoleId;

	@NotNull
	@Column(name = "FK_OSHA_USER_ID")
	private Integer oshaUserId;

	@NotNull
	@Column(name = "FK_USER_ROLE_ID")
	private Integer userRoleId;

	// @NotNull
	@Column(name = "PRIMARY_IND")
	private String primaryIndicator;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
