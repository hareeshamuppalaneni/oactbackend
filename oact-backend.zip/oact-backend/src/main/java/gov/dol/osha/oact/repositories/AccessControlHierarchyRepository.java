package gov.dol.osha.oact.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import gov.dol.osha.oact.entities.AccessControlHierarchy;

/**
 * Repository interface for {@link AccessControlHierarchy} instances. Provides
 * basic CRUD operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface AccessControlHierarchyRepository extends JpaRepository<AccessControlHierarchy, Integer> {

}
