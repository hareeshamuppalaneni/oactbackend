package gov.dol.osha.oact.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the STND_USER_ROLE information
 *
 * @author Skietech Development Team
 */
@Table(name = "OACT_STND_USER_ROLE")
@Entity
@Data
@RequiredArgsConstructor
public class StandardUserRole {

	@Id
	@GeneratedValue
	@Column(name = "USER_ROLE_ID")
	private Integer stndUserRoleId;

	@NotBlank(message = "User role name is mandatory")
	@Size(min = 1, max = 200)
	@Column(name = "USER_ROLE_NM", length = 200)
	private String userRoleName;

	@NotBlank(message = "User role description is mandatory")
	@Size(min = 1, max = 200)
	@Column(name = "DESCRIPTION_TX", length = 2000)
	private String descriptionText;

	@Size(min = 0, max = 200)
	@Column(name = "DISPLAY_NM", length = 200)
	private String dispalyName;

	@Embedded
	@Valid
	@NotNull(message = "Audit information is mandatory")
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
