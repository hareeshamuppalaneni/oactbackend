package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide OSHA user roles data.
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class OSHAUserRoleResponse {

	private OSHAUserData userInformation;
	private List<StandardUserRoleData> roleInformation = new ArrayList<>();

}
