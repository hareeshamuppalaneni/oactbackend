package gov.dol.osha.oact.domain;

import java.time.LocalDate;

import lombok.Data;

@Data
public class CycleData {

	private Integer cycleStateId;
	private LocalDate cycleStartDate;
	private LocalDate cycleDueDate;
	private String cycleName;
	private String fileRefernceId;
	private Integer cycleHirerchyId;
}
