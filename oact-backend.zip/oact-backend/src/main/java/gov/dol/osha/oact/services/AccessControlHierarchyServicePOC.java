package gov.dol.osha.oact.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import gov.dol.osha.oact.domain.AccessControlHierarchyDataSummary;
import gov.dol.osha.oact.domain.AccessControlHierarchyPOCData;
import gov.dol.osha.oact.domain.AccessControlHierarchyPOCFlowData;
import gov.dol.osha.oact.domain.AccessControlHierarchyPOCFlowSummary;
import gov.dol.osha.oact.domain.OSHAUserData;
import gov.dol.osha.oact.domain.OSHAUserRoleResponse;
import gov.dol.osha.oact.domain.OSHAUserSummaryData;
import gov.dol.osha.oact.domain.StandardCycleData;
import gov.dol.osha.oact.domain.searchQuery.AccessControlHierarchyPOCQuery;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserRoleQuery;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserSearchQuery;
import gov.dol.osha.oact.entities.AccessControlHierarchy;
import gov.dol.osha.oact.entities.AccessControlHierarchyPOC;
import gov.dol.osha.oact.entities.LifeCycle;
import gov.dol.osha.oact.entities.OSHAUser;
import gov.dol.osha.oact.entities.StandardCycle;
import gov.dol.osha.oact.repositories.AccessControlHierarchyRepositoryPOC;
import gov.dol.osha.oact.repositories.StandardCycleRepository;
import gov.dol.osha.oact.utils.AuditInformation;
import gov.dol.osha.oact.validation.OSHACommonValidations;

@Validated
@Service
public class AccessControlHierarchyServicePOC {

	@Autowired
	private AccessControlHierarchyRepositoryPOC hierarchyRepositoryPoc;

	@Autowired
	private AuditInformation auditInformation;

	@Autowired
	private OSHAUserService userService;

	@Autowired
	private OSHAUserRoleService userRoleService;

	@Autowired
	private StandardCycleRepository stndCycleRepository;

	public List<AccessControlHierarchyPOCData> getAccessControlHierarchyPOCData(
			@NotNull final AccessControlHierarchyPOCQuery searchQuery) {

		final AccessControlHierarchyPOC accessControlHierarchyPOC = new AccessControlHierarchyPOC();
		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		accessControlHierarchy.setAccessControlHierarchyId(searchQuery.getParentHierarchyId());
		accessControlHierarchyPOC.setAccessControlHierarchy(accessControlHierarchy);
		accessControlHierarchyPOC.setAccessControlHierarchyPocId(searchQuery.getHierarchyPocId());

		final Example<AccessControlHierarchyPOC> queryParameters = Example.of(accessControlHierarchyPOC);
		final List<AccessControlHierarchyPOC> accessControlHierarchies = hierarchyRepositoryPoc
				.findAll(queryParameters);

		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(accessControlHierarchies, "hierarchy poc");
		final List<AccessControlHierarchyPOCData> accessControlHierarchyPOCDataBag = new ArrayList<>();

		accessControlHierarchies.stream().forEach(hierarchyData -> {

			final AccessControlHierarchyPOCData accessControlHierarchyPOCData = new AccessControlHierarchyPOCData();
			BeanUtils.copyProperties(hierarchyData, accessControlHierarchyPOCData);
			accessControlHierarchyPOCData.setAuditData(auditInformation.getAuditData(hierarchyData.getAuditData()));
			accessControlHierarchyPOCData.setParentAccessControlHierarchyId(
					hierarchyData.getAccessControlHierarchy().getAccessControlHierarchyId());
			accessControlHierarchyPOCData.setAccountManager(copyManagersData(hierarchyData.getAccountManager()));
			accessControlHierarchyPOCData.setCertCoOrdinator(copyManagersData(hierarchyData.getCertCoordinator()));
			accessControlHierarchyPOCData.setSubaccountManager(copyManagersData(hierarchyData.getSubAccountManager()));
			accessControlHierarchyPOCData.setSystemOwner(copyManagersData(hierarchyData.getSystemOwner()));
			accessControlHierarchyPOCData.setSystemPoc(copyManagersData(hierarchyData.getSystemPoc()));
			accessControlHierarchyPOCDataBag.add(accessControlHierarchyPOCData);
		});

		return accessControlHierarchyPOCDataBag;
	}

	private OSHAUserSummaryData copyManagersData(OSHAUser oshaUserEnt) {
		OSHAUserSummaryData userSummaryData = null;
		if (null != oshaUserEnt) {
			userSummaryData = new OSHAUserSummaryData();
			BeanUtils.copyProperties(oshaUserEnt, userSummaryData);
		}
		return userSummaryData;
	}

	public AccessControlHierarchyPOCData createAccessControlHierarchyPOC(
			@NotNull AccessControlHierarchyPOCData hierarchyDataReq) {

		final AccessControlHierarchyPOC accessControlHierarchyPOC = new AccessControlHierarchyPOC();
		BeanUtils.copyProperties(hierarchyDataReq, accessControlHierarchyPOC);
		accessControlHierarchyPOC.setAuditData(
				auditInformation.setCreatorAuditData(hierarchyDataReq.getAuditData().getLastModifiedUserId()));
		accessControlHierarchyPOC.setLifeCycleData(auditInformation.setCreateLifeCycle());

		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		accessControlHierarchy.setAccessControlHierarchyId(hierarchyDataReq.getParentAccessControlHierarchyId());
		accessControlHierarchyPOC.setAccessControlHierarchy(accessControlHierarchy);
		setManagersData(accessControlHierarchyPOC, hierarchyDataReq);

		hierarchyRepositoryPoc.save(accessControlHierarchyPOC);
		return hierarchyDataReq;
	}

	public AccessControlHierarchyPOCData updateAccessControlHierarchyPOC(
			@NotNull AccessControlHierarchyPOCData hierarchyDataReq) {

		OSHACommonValidations.updateServiceInputValidation(hierarchyDataReq.getAccessControlHierarchyPocId(),
				hierarchyDataReq.getAuditData().getLockControlNumber());

		final AccessControlHierarchyPOC accessControlHierarchyPOC = getAccessControlHierarchyPOCById(
				hierarchyDataReq.getAccessControlHierarchyPocId());
		OSHACommonValidations.safeLockControlNumber(hierarchyDataReq.getAuditData().getLockControlNumber(),
				accessControlHierarchyPOC.getAuditData().getLockControlNumber());
		BeanUtils.copyProperties(hierarchyDataReq, accessControlHierarchyPOC);
		accessControlHierarchyPOC.setAuditData(auditInformation.setUpdateAuditData(hierarchyDataReq.getAuditData(),
				accessControlHierarchyPOC.getAuditData()));

		final AccessControlHierarchy accessControlHierarchy = new AccessControlHierarchy();
		accessControlHierarchy.setAccessControlHierarchyId(hierarchyDataReq.getParentAccessControlHierarchyId());
		accessControlHierarchyPOC.setAccessControlHierarchy(accessControlHierarchy);
		setManagersData(accessControlHierarchyPOC, hierarchyDataReq);
		hierarchyRepositoryPoc.save(accessControlHierarchyPOC);
		return hierarchyDataReq;
	}

	private void setManagersData(final AccessControlHierarchyPOC accessControlHierarchyPOC,
			final AccessControlHierarchyPOCData hierarchyDataReq) {
		accessControlHierarchyPOC.setAccountManager(setPOCManagersData(hierarchyDataReq.getAccountManager()));
		accessControlHierarchyPOC.setCertCoordinator(setPOCManagersData(hierarchyDataReq.getCertCoOrdinator()));
		accessControlHierarchyPOC.setSubAccountManager(setPOCManagersData(hierarchyDataReq.getSubaccountManager()));
		accessControlHierarchyPOC.setSystemOwner(setPOCManagersData(hierarchyDataReq.getSystemOwner()));
		accessControlHierarchyPOC.setSystemPoc(setPOCManagersData(hierarchyDataReq.getSystemPoc()));
	}

	private OSHAUser setPOCManagersData(OSHAUserSummaryData managerReqData) {
		OSHAUser managerEntData = null;
		if (null != managerReqData) {
			managerEntData = userService.getOSHAUserById(managerReqData.getOshaUserId());
		}
		return managerEntData;
	}

	public void deleteAccessControlHierarchyPOC(@NotNull Integer hierarchyPOCId) {

		hierarchyRepositoryPoc.delete(getAccessControlHierarchyPOCById(hierarchyPOCId));
	}

	private AccessControlHierarchyPOC getAccessControlHierarchyPOCById(Integer hierarchyPOCId) {

		final Optional<AccessControlHierarchyPOC> accessControlHierarchyOpt = hierarchyRepositoryPoc
				.findById(hierarchyPOCId);
		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDBObject(
				accessControlHierarchyOpt.isEmpty() ? null : accessControlHierarchyOpt.get(), "hierarchy poc");

		return accessControlHierarchyOpt.get();
	}

	public AccessControlHierarchyPOCFlowSummary getAccessControlHierarchyPOCFlowById(@NotNull final Integer pocId) {

		Optional<AccessControlHierarchyPOC> hierarchyPoc = hierarchyRepositoryPoc.findById(pocId);
		AccessControlHierarchyPOCFlowSummary pocFlowData = null;

		if (null != hierarchyPoc) {

			AccessControlHierarchyPOC acHierarchyPOC = hierarchyPoc.get();
			pocFlowData = new AccessControlHierarchyPOCFlowSummary();

			pocFlowData.setAccessControlHierarchyPocId(acHierarchyPOC.getAccessControlHierarchyPocId());
			pocFlowData.setAccountManager(
					userService.getUserFullNameById(acHierarchyPOC.getAccountManager().getOshaUserId()));
			pocFlowData.setAccountManagerOfc(acHierarchyPOC.getAccountManagerOfc());
			pocFlowData.setCertCoOrdinator(
					userService.getUserFullNameById(acHierarchyPOC.getCertCoordinator().getOshaUserId()));
			pocFlowData.setSubaccountManager(
					userService.getUserFullNameById(acHierarchyPOC.getSubAccountManager().getOshaUserId()));
			pocFlowData
					.setSystemOwner(userService.getUserFullNameById(acHierarchyPOC.getSystemOwner().getOshaUserId()));
			pocFlowData.setSystemPoc(userService.getUserFullNameById(acHierarchyPOC.getSystemPoc().getOshaUserId()));
			if (null != acHierarchyPOC.getAccessControlHierarchy())
				pocFlowData.setApplicationName(acHierarchyPOC.getAccessControlHierarchy().getOrganizationType());
		}

		return pocFlowData;
	}

	public List<AccessControlHierarchyPOCFlowData> getAccessControlHierarchyPOCFlow(
			@NotNull final OSHAUserSearchQuery searchQuery) {

		final List<OSHAUserData> loginUserDataBag = userService.getOSHAUserDataByQueryParameter(searchQuery);
		final OSHAUserData loginUserData = loginUserDataBag.get(0);
		final Integer loginUserId = loginUserData.getOshaUserId();

		final OSHAUserRoleQuery userRoleSearchQuery = new OSHAUserRoleQuery();
		userRoleSearchQuery.setUserId(loginUserId);
		OSHAUserRoleResponse userRoleResp = userRoleService.getOSHAUserRoleData(userRoleSearchQuery);

		List<AccessControlHierarchyPOCFlowData> hierarchyFlowDataBag = new ArrayList<>();

		userRoleResp.getRoleInformation().stream().forEach(indRole -> {

			if (StringUtils.contains(indRole.getUserRoleName(), "AM")) {
				getHierarchyFlowData(hierarchyFlowDataBag,
						hierarchyRepositoryPoc.findByAccountManagerOshaUserId(loginUserId));
			}
			if (StringUtils.contains(indRole.getUserRoleName(), "CC")) {
				getHierarchyFlowData(hierarchyFlowDataBag,
						hierarchyRepositoryPoc.findByCertCoordinatorOshaUserId(loginUserId));
			}
			if (StringUtils.contains(indRole.getUserRoleName(), "SO")) {
				getHierarchyFlowData(hierarchyFlowDataBag,
						hierarchyRepositoryPoc.findBySystemOwnerOshaUserId(loginUserId));
			}
			if (StringUtils.contains(indRole.getUserRoleName(), "SAM")) {
				getHierarchyFlowData(hierarchyFlowDataBag,
						hierarchyRepositoryPoc.findBySubAccountManagerOshaUserId(loginUserId));
			}

		});

		OSHACommonValidations.checkSearchCriteriaHaveDataInTheDB(hierarchyFlowDataBag, "hierarchy poc");

		List<AccessControlHierarchyPOCFlowData> distinctFlowDataBag = hierarchyFlowDataBag.stream().distinct()
				.collect(Collectors.toList());
		return distinctFlowDataBag;
	}

	private void getHierarchyFlowData(List<AccessControlHierarchyPOCFlowData> completeFlowDataBag,
			List<AccessControlHierarchyPOC> individualPOCBag) {

		if (CollectionUtils.isNotEmpty(individualPOCBag)) {

			individualPOCBag.stream().forEach(indData -> {

				final AccessControlHierarchyPOCFlowData pocFlowData = new AccessControlHierarchyPOCFlowData();
				pocFlowData.setAccessControlHierarchyPocId(indData.getAccessControlHierarchyPocId());
				pocFlowData.setAccountManager(
						userService.getUserFullNameById(indData.getAccountManager().getOshaUserId()));
				pocFlowData.setAccountManagerOfc(indData.getAccountManagerOfc());
				pocFlowData.setCertCoOrdinator(
						userService.getUserFullNameById(indData.getCertCoordinator().getOshaUserId()));
				pocFlowData.setSubaccountManager(
						userService.getUserFullNameById(indData.getSubAccountManager().getOshaUserId()));
				pocFlowData.setSystemOwner(userService.getUserFullNameById(indData.getSystemOwner().getOshaUserId()));
				pocFlowData.setSystemPoc(userService.getUserFullNameById(indData.getSystemPoc().getOshaUserId()));

				if (null != indData.getAccessControlHierarchy()) {
					final AccessControlHierarchy hierarchyEnt = indData.getAccessControlHierarchy();
					final AccessControlHierarchyDataSummary hierarchyData = new AccessControlHierarchyDataSummary();
					hierarchyData.setAccessControlHierarchyId(hierarchyEnt.getAccessControlHierarchyId());
					hierarchyData.setDescriptionText(hierarchyEnt.getDescriptionText());
					hierarchyData.setName(hierarchyEnt.getName());
					hierarchyData.setOrganizationType(hierarchyEnt.getOrganizationType());
					hierarchyData.setParentAccessControlHierarchyId(hierarchyEnt.getParentAccessControlHierarchyId());
					pocFlowData.setApplication(hierarchyData);
				}

				final StandardCycle stndCycleData = stndCycleRepository.getCurrentStandardCyle();

				if (null != stndCycleData) {

					final StandardCycleData cycleData = new StandardCycleData();
					BeanUtils.copyProperties(stndCycleData, cycleData);
					final LifeCycle lifeCycleData = new LifeCycle();
					lifeCycleData.setBeginEffectiveDate(stndCycleData.getLifeCycleData().getBeginEffectiveDate());
					lifeCycleData.setEndEffectiveDate(stndCycleData.getLifeCycleData().getEndEffectiveDate());
					pocFlowData.setCycleData(cycleData);
				}

				completeFlowDataBag.add(pocFlowData);
			});
		}
	}

}
