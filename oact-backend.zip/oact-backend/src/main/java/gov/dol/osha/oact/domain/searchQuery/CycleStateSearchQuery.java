package gov.dol.osha.oact.domain.searchQuery;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * This class is used for Cycle State Search
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
public class CycleStateSearchQuery {

	private Integer cycleStateId;
	private String stateName;
	private String subStateName;
}
