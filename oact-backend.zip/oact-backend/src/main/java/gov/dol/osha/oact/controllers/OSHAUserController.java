package gov.dol.osha.oact.controllers;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.dol.osha.oact.domain.OSHAUserData;
import gov.dol.osha.oact.domain.searchQuery.OSHAUserSearchQuery;
import gov.dol.osha.oact.services.OSHAUserService;

/**
 * Controller to handle OSHA users data
 *
 * @author Skietech Development Team
 */
@RestController
@RequestMapping("/osha-users")
public class OSHAUserController {

	@Autowired
	private OSHAUserService userService;

	@GetMapping
	public List<OSHAUserData> getOSHAUsersData(final OSHAUserSearchQuery userSearchQuery) {

		return userService.getOSHAUserDataByQueryParameter(userSearchQuery);
	}

	@PostMapping
	public OSHAUserData createOSHAUsersData(@Valid @RequestBody final OSHAUserData oshaUserData) {

		return userService.createUserData(oshaUserData);

	}

	@PutMapping
	public OSHAUserData updateOSHAUsersData(@Valid @RequestBody final OSHAUserData oshaUserData) {

		return userService.updateUserData(oshaUserData);

	}

	@DeleteMapping(value = "/{userId}")
	public void deleteOSHAUsersData(@NotNull @PathVariable("userId") final Integer userId) {

		userService.deleteUserData(userId);
	}

}
