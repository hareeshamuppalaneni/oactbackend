package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide Access Control Hierarchy data
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class CycleStateData {

	private Integer cycleStateId;

	@NotBlank(message = "State name is mandatory")
	@Size(min = 1, max = 100)
	private String stateName;

	@NotBlank(message = "Sub state name is mandatory")
	@Size(min = 0, max = 100)
	private String subStateName;

	@Size(min = 0, max = 1000)
	private String descriptionText;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;
}
