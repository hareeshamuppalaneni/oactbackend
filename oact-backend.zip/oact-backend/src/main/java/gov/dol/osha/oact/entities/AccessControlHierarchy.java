package gov.dol.osha.oact.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Entity capturing the ACCESS_CONTROL_HIERARCHY information
 *
 * @author Skietech Development Team
 */
@Table(name = "OACT_ACCESS_CTRL_HIERARCHY")
@Entity
@Getter
@Setter
@RequiredArgsConstructor
public class AccessControlHierarchy {

	@Id
	@GeneratedValue
	@Column(name = "ACH_ID")
	private Integer accessControlHierarchyId;

	@NotBlank(message = "Access control hierarchy name is mandatory")
	@Size(min = 1, max = 100)
	@Column(name = "NM", length = 100)
	private String name;

	@Size(min = 0, max = 1000)
	@Column(name = "DESCRIPTION_TX", length = 1000)
	private String descriptionText;

	@Size(min = 0, max = 1000)
	@Column(name = "ORG_TYPE", length = 1000)
	private String organizationType;

	@NotNull
	@Column(name = "FK_PRNT_ACH_ID")
	private Integer parentAccessControlHierarchyId;

	@OneToMany(mappedBy = "accessControlHierarchy")
	private List<AccessControlHierarchyPOC> acHierarchyPOCBag;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
