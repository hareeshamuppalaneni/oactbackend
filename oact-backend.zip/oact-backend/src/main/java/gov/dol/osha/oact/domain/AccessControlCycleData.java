package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * This class is used to provide Access control cycle data.
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class AccessControlCycleData {

	private Integer certificationCycleId;

	@NotBlank(message = "Csycle name is mandatory")
	@Size(min = 1, max = 100)
	private String name;

	@Size(min = 0, max = 1000)
	private String descriptionText;

	@NotNull(message = "Cycle due date is mandatory")
	private LocalDate dueDate;

	@NotNull(message = "Cycle start date is mandatory")
	private LocalDate cycleStartDate;

	private LocalDate cycleEndDate;

	private String fiscalQuarter;

	private String fiscalYear;

	@NotNull(message = "Access control hirerachy id is mandatory")
	private Integer accessControlHierarchyId;

	private Integer cycleStateId;

	@Valid
	@NotNull(message = "Audit data is mandatory")
	private AuditData auditData;
}
