package gov.dol.osha.oact.domain;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.dol.osha.oact.entities.LifeCycle;
import lombok.Data;

/**
 * This class is used to provide Access Control Hierarchy data
 *
 * @author Skietech Development Team
 */
@Data
@JsonInclude(NON_NULL)
public class StandardCycleData {

	private Integer stndCycleId;

	private String cycleName;

	private String descriptionText;

	private LifeCycle lifeCycleData;
}
