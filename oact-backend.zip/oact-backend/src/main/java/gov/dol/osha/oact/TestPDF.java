package gov.dol.osha.oact;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;

public class TestPDF {
	public static void main(String[] args) throws Exception {
		// String inputFile="/Users/rramani/Documents/OSHA/Semi-Annual Account
		// Certification Attestation_UPD.docx";
		String outputFile = "/Users/rramani/Documents/OSHA/Semi-Annual Account Certification Attestation_UPD.pdf";
		if (args != null && args.length == 2) {

			outputFile = args[1];
		}

		try {
			XWPFDocument doc = new XWPFDocument(OPCPackage
					.open("/Users/rramani/Documents/OSHA/Semi-Annual Account Certification Attestation_UPD.docx"));

			for (XWPFParagraph p : doc.getParagraphs()) {
				for (XWPFRun r : p.getRuns()) {
					String text = r.getText(0);
					if (text != null && text.contains("$SYSTEM$")) {
						text = text.replace("$SYSTEM$", "hhhhhhhhh");
						r.setText(text, 0);
					}
					if (text != null && text.contains("$APPLICATION$")) {
						text = text.replace("$APPLICATION$", "hhhhhxxxxxhhhh");
						r.setText(text, 0);
					}
					if (text != null && text.contains("$CONTACT$")) {
						text = text.replace("$CONTACT$", "hssh");
						r.setText(text, 0);
					}

					if (text != null && text.contains("$PHONE$")) {
						text = text.replace("$PHONE$", "PHONE");
						r.setText(text, 0);
					}

				}
			}

			String fileName = "/Users/rramani/Documents/OSHA/Semi-Annual Account Certification Attestation_UPD11.docx";
			doc.write(new FileOutputStream(fileName));
			FileInputStream in = new FileInputStream(fileName);
			XWPFDocument document = new XWPFDocument(in);
			File outFile = new File(outputFile);
			OutputStream out = new FileOutputStream(outFile);
			PdfOptions options = null;
			PdfConverter.getInstance().convert(document, out, options);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}