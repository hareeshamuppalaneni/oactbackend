package gov.dol.osha.oact.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import gov.dol.osha.oact.entities.StandardUserRole;

/**
 * Repository interface for {@link StandardUserRole} instances. Provides basic
 * CRUD operations due to the extension of {@link JpaRepository}.
 *
 * @author Skietech Development Team
 */
public interface StandardUserRoleRepository extends JpaRepository<StandardUserRole, Integer> {

}
