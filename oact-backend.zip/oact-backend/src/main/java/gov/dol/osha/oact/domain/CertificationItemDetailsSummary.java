package gov.dol.osha.oact.domain;

import java.time.LocalDate;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Entity capturing the CertificationItemDetailsData information
 *
 * @author Skietech Development Team
 */
@Data
@RequiredArgsConstructor
public class CertificationItemDetailsSummary {

	private Integer cycleItemId;

	private String name;

	private String descriptionText;

	private LocalDate dueDate;

	private String itemDetails;

}
