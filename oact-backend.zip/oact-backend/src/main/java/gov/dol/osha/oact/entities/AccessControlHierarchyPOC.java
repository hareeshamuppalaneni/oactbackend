package gov.dol.osha.oact.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Entity capturing the ACCESS_CONTROL_HIERARCHY information
 *
 */
@Table(name = "ACCESS_CONTROL_HIERARCHY_POC")
@Entity
@Getter
@Setter
@RequiredArgsConstructor
public class AccessControlHierarchyPOC {

	@Id
	@GeneratedValue
	@Column(name = "ACHP_ID")
	private Integer accessControlHierarchyPocId;

	@ManyToOne
	@JoinColumn(name = "FK_SYSTEM_OWNER_ID", referencedColumnName = "OSHA_USER_ID")
	private OSHAUser systemOwner;

	@ManyToOne
	@JoinColumn(name = "FK_SYSTEM_POC_ID", referencedColumnName = "OSHA_USER_ID")
	private OSHAUser systemPoc;

	@ManyToOne
	@JoinColumn(name = "FK_CERTIFICATION_CORD_ID", referencedColumnName = "OSHA_USER_ID")
	private OSHAUser certCoordinator;

	@ManyToOne
	@JoinColumn(name = "FK_ACCOUNT_MANAGER_ID", referencedColumnName = "OSHA_USER_ID")
	private OSHAUser accountManager;

	@ManyToOne
	@JoinColumn(name = "FK_SUB_ACCOUNT_MANAGER_ID", referencedColumnName = "OSHA_USER_ID")
	private OSHAUser subAccountManager;

	@Size(min = 1, max = 1000)
	@Column(name = "ACCOUNT_MANAGER_OFC", length = 1000)
	private String accountManagerOfc;

	@NotNull
	@ManyToOne
	@JoinColumn(name = "FK_ACH_ID")
	private AccessControlHierarchy accessControlHierarchy;

	@Embedded
	@Valid
	@NotNull
	private Audit auditData;

	@Embedded
	private LifeCycle lifeCycleData;
}
