package gov.dol.osha.oact.domain.searchQuery;

import lombok.Data;

/**
 * This class is used for Access Control Hierarchy Search
 *
 * @author Skietech Development Team
 */
@Data
public class AccessControlHierarchyQuery {

	private Integer accessControlHierarchyId;
	private Integer parentAccessControlHierarchyId;
	private String organizationType;
	private String systemOwner;
	private String accountManager;
	private String name;
}
