package gov.dol.osha.oact.domain;

import java.util.List;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class CycleAttestationReq {

	@NotBlank(message = "Email id is mandatory")
	private String emailId;

	@NotBlank(message = "Cycle id is mandatory")
	private List<Integer> cycleId;
}
