package gov.osha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OshaServicesApplicationTests {

	//@Test
	void contextLoads() {
	}

}
